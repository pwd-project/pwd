jQuery(function(){
	jQuery(".element-invisible").removeClass("element-invisible");

	jQuery(".blog .item").each(function(){
		var wiecej = jQuery(this).find(".readmore").html();
			jQuery(this).find(".readmore a").unwrap().addClass("readmore").hide();
			
		jQuery(this).find("p:last").append(wiecej);
	})
})