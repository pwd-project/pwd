<?php
defined('_JEXEC') or die;

/**
 * Template for Joomla! CMS, created with .
 * See readme.txt for more details on how to use the template.
 */

require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'functions.php';

// Create alias for $this object reference:
$document = $this;

// Shortcut for template base url:
$templateUrl = $document->baseurl . '/templates/' . $document->template;

Artx::load("Artx_Page");

// Initialize $view:
$view = $this->artx = new ArtxPage($this);

// Decorate component with  style:
$view->componentWrapper();

JHtml::_('behavior.framework', true);

?>
<!DOCTYPE html>
<html dir="ltr" lang="<?php echo $document->language; ?>">
<head>
    <jdoc:include type="head" />
    <link rel="stylesheet" href="<?php echo $document->baseurl; ?>/templates/system/css/system.css" />
    <link rel="stylesheet" href="<?php echo $document->baseurl; ?>/templates/system/css/general.css" />

    <!-- Created by  v4.3.0.60745 -->
    
    
    <meta name="viewport" content="initial-scale = 1.0, maximum-scale = 1.0, user-scalable = no, width = device-width" />

    <!--[if lt IE 9]><script src="https://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
    <link rel="stylesheet" href="<?php echo $templateUrl; ?>/css/template.css" media="screen" type="text/css" />
    <!--[if lte IE 7]><link rel="stylesheet" href="<?php echo $templateUrl; ?>/css/template.ie7.css" media="screen" /><![endif]-->
    <link rel="stylesheet" href="<?php echo $templateUrl; ?>/css/template.responsive.css" media="all" type="text/css" />
<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Lato&amp;subset=latin" />
<link rel="shortcut icon" href="<?php echo $templateUrl; ?>/favicon.ico" type="image/x-icon" />
    <script>if ('undefined' != typeof jQuery) document._artxJQueryBackup = jQuery;</script>
    <script src="<?php echo $templateUrl; ?>/jquery.js"></script>
    <script>jQuery.noConflict();</script>

    <script src="<?php echo $templateUrl; ?>/script.js"></script>
    <script src="<?php echo $templateUrl; ?>/script.responsive.js"></script>
    <script src="<?php echo $templateUrl; ?>/modules.js"></script>
    <?php $view->includeInlineScripts() ?>
    <script>if (document._artxJQueryBackup) jQuery = document._artxJQueryBackup;</script>
</head>
<body>

<div id="amain">
<header class="aheader"><?php echo $view->position('header', 'anostyle'); ?>

    <div class="ashapes">
        
            </div>






<?php if ($view->containsModules('user3', 'extra1', 'extra2')) : ?>
<nav class="anav">
    
<?php if ($view->containsModules('extra1')) : ?>
<div class="ahmenu-extra1"><?php echo $view->position('extra1'); ?></div>
<?php endif; ?>
<?php if ($view->containsModules('extra2')) : ?>
<div class="ahmenu-extra2"><?php echo $view->position('extra2'); ?></div>
<?php endif; ?>
<?php echo $view->position('user3'); ?>
 
    </nav>
<?php endif; ?>

                    
</header>
<div class="asheet clearfix">
            <?php echo $view->position('banner1', 'anostyle'); ?>
<?php echo $view->positions(array('top1' => 33, 'top2' => 33, 'top3' => 34), 'ablock'); ?>
<div class="alayout-wrapper">
                <div class="acontent-layout">
                    <div class="acontent-layout-row">
                        <?php if ($view->containsModules('left')) : ?>
<div class="alayout-cell asidebar1">
<?php echo $view->position('left', 'ablock'); ?>




                        </div>
<?php endif; ?>
                        <div class="alayout-cell acontent">
<?php
  echo $view->position('banner2', 'anostyle');
  if ($view->containsModules('breadcrumb'))
    echo artxPost($view->position('breadcrumb'));
  echo $view->positions(array('user1' => 50, 'user2' => 50), 'aarticle');
  echo $view->position('banner3', 'anostyle');
  echo artxPost(array('content' => '<jdoc:include type="message" />', 'classes' => ' amessages'));
  echo '<jdoc:include type="component" />';
  echo $view->position('banner4', 'anostyle');
  echo $view->positions(array('user4' => 50, 'user5' => 50), 'aarticle');
  echo $view->position('banner5', 'anostyle');
?>



                        </div>
                    </div>
                </div>
            </div>
<?php echo $view->positions(array('bottom1' => 33, 'bottom2' => 33, 'bottom3' => 34), 'ablock'); ?>
<?php echo $view->position('banner6', 'anostyle'); ?>

<footer class="afooter">
<div class="acontent-layout">
    <div class="acontent-layout-row">
    <div class="alayout-cell layout-item-0" style="width: 50%">
<?php if ($view->containsModules('footer1')) : ?>
    <?php echo $view->position('footer1', 'anostyle'); ?>
<?php else: ?>
        <p style="text-align: center;"><span style="font-size: 14px;">Szablon został opracowany w ramach projektu &nbsp;&nbsp;<img width="100" height="15" alt="" class="alightbox" src="<?php echo $document->baseurl ?>/templates/<?php echo $document->template; ?>/images/pwd-logo-png.png" />&nbsp; &nbsp;PW D Online prowadzonego przez Stowarzyszenie na rzecz Rozwoju Dolina Gubra i Ministerstwo Administracji i Cyfryzacji www.pwd.dolinagubra.pl, wersja 1.0</span><br /></p>
    <?php endif; ?>
</div><div class="alayout-cell layout-item-0" style="width: 50%">
<?php if ($view->containsModules('footer2')) : ?>
    <?php echo $view->position('footer2', 'anostyle'); ?>
<?php else: ?>
        <p><img width="156" height="88" alt="" class="alightbox" src="<?php echo $document->baseurl ?>/templates/<?php echo $document->template; ?>/images/mac.png" />&nbsp;<img width="217" height="88" alt="" class="alightbox" src="<?php echo $document->baseurl ?>/templates/<?php echo $document->template; ?>/images/dgubara.png" /><br /></p>
    <?php endif; ?>
</div>
    </div>
</div>

</footer>

    </div>
</div>


<?php echo $view->position('debug'); ?>
</body>
</html>