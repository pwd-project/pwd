jQuery(document).ready(function(){
	  jQuery(".button-collapse").sideNav();
});

jQuery(document).ready(function(){
	jQuery('.show_sub_menu').click(function(){
		jQuery('.under_menu').slideUp();
		var menu = jQuery(this).attr('data-menu');
		console.log(menu);
		jQuery('#'+menu).slideDown();
	});
});

function do_on_resize_and_load()
{

}

jQuery(document).ready(function(){
	jQuery('form img').click(function(){
		jQuery('form').submit();
	});
});

jQuery(document).ready(function(){
	do_on_resize_and_load();
});

jQuery(window).load(function(){
	var left_col_h = jQuery('.main_content_page').height();

	jQuery('.lef_col_faker_width').height(left_col_h);
});

jQuery( window ).resize(function() {
  	do_on_resize_and_load();
});

jQuery(document).ready(function(){
	var current_con = "def";
	var ca = document.cookie.split(';');
	for(var i=0; i<ca.length; i++) 
	{
        var c_val = ca[i];
        spl_c = c_val.split('=');
        if(spl_c[0] == "contrast")
        {
        	var current_con = spl_c[1];
        }
	}
    
	if(current_con == "def")
    {
    	jQuery("body").removeClass();
    	jQuery("body").addClass("default_styling");
    }

    if(current_con == "1")
    {
    	jQuery("body").removeClass();
    	jQuery("body").addClass("op_1_styling");
    }

    if(current_con == "2")
    {
    	jQuery("body").removeClass();
    	jQuery("body").addClass("op_2_styling");
    }

    if(current_con == "3")
    {
    	jQuery("body").removeClass();
    	jQuery("body").addClass("op_3_styling");
    }

    jQuery('.con_op_1').click(function(){
    	document.cookie="contrast=def";
    	jQuery("body").removeClass();
    	jQuery("body").addClass("default_styling");
    });

    jQuery('.con_op_2').click(function(){
    	document.cookie="contrast=1";
    	jQuery("body").removeClass();
    	jQuery("body").addClass("op_1_styling");
    });

    jQuery('.con_op_3').click(function(){
    	document.cookie="contrast=2";
    	jQuery("body").removeClass();
    	jQuery("body").addClass("op_2_styling");
    });

    jQuery('.con_op_4').click(function(){
    	document.cookie="contrast=3";
    	jQuery("body").removeClass();
    	jQuery("body").addClass("op_3_styling");
    });
});

jQuery(document).ready(function(){

	var plus = 0;
		jQuery('.default_size').click(function() {
			jQuery('p, .section span, h1, h2, h3, h4, h5, h6, .side_menu_left li, .footer .col').removeAttr('style');
			plus=0;
		});
		jQuery('.medium_size').click(function() {
			jQuery('p, .section span, h1, h2, h3, h4, h5, h6, .side_menu_left li, .footer .col').removeAttr('style');
			jQuery('p, .section span, h1, h2, h3, h4, h5, h6, .side_menu_left li, .footer .col').css("font-size", function() {
				plus=plus+1;
				return parseInt(jQuery(this).css('font-size')) * 1.5 + 'px';		
			});
		});
		jQuery('.higher_size').click(function() {
			jQuery('p, .section span, h1, h2, h3, h4, h5, h6, .side_menu_left li, .footer .col').removeAttr('style');
			jQuery('p, .section span, h1, h2, h3, h4, h5, h6, .side_menu_left li, .footer .col').css("font-size", function() {
				
				return parseInt(jQuery(this).css('font-size')) * 2 + 'px';		
			});
		
		});
});


