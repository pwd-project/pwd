                    
Installing New Themes-
--------------------- 

To install a new Theme to your Joomla installation, follow these basic steps:-
...............................................................................

Install via Admin Panel (packed template file):
---------------------------------------------- 

1.Log in to the Joomla administration back-end.

2.Select Extensions / Install/Uninstall from the top menu.

Here you will have the various options: 
 
Upload Package File - (select a package from your PC, upload and install it)
...................

Install from Directory - (enter the path where the package is located on your server)
......................

Install from URL - (enter the URL to the package)
................


3.In the panel Upload package file, click Browse and locate the installation package you have exported to your local computer.

4.Click the button Upload & Install.

5.Now Select  Extensions->TemplateManager from top menu.

6.Select the currently installed template from the list.

7.click the Make Default button to make your selected template default.


Install via FTP(unpacked template file):
---------------------------------------

Joomla template can be installed via FTP of Template Toaster without packaging them.

1.Click on upload button in TemplateToaster to open FTP client in a new tab.

2.connect to FTP server using hostname,username and password.

3.select web server folder in FTP server section where you want to upload the theme.

4.Select your exported joomla theme directory via client's computer section.Right click the selected

5.upload the theme directory to /templates/ directory provided by joomla.

6.Now Select  Extensions->TemplateManager from top menu.

7.Select the currently installed template from the list.

8.Click the Make Default button to make your selected template default.


Configuring Modules:-
--------------------

 You need to place desired modules on positions available in the new template from Extensions>> Module Manager from your Joomla admin and add the content/pages from Article Manager. While placing the module on an available position make sure to select the desired pages (from bottom of the page) where you want to display that menu.
 

Configuring Horizontal Menu:-
----------------------------

 Go to Menus>> Main Menu or create a new menu from there, Add a new menu item and assign desired article to it, place your menu module on �Menu� position from extensions>> module manager. While placing the menu on menu position make sure to select the desired pages (from bottom of the page) where you want to display that menu.


Configuring Sidebar Menu:-
-------------------------

 Go to Menus>> Main Menu or create a new menu from there, Add a new menu item and assign desired article to it, place your menu module on �left� or �right� position from extensions>> module manager. While placing the menu on menu position make sure to select the desired pages (from bottom of the page) where you want to display that menu.


Footer Links:-
-------------

 Go to Extensions>> Module Manager>> Click New from Top Right>> Select Custom HTML>> Click New on Top Right>> On next page select �Footer� under Position Drop Down menu>> Add desired content and links using the content editor on bottom>> Clock Save from top Right.



    






