<?php 
defined('_JEXEC') or die ('Restricted access');
 $app	= JFactory::getApplication();
$doc = JFactory::getDocument();
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>">
<head>
<jdoc:include type="head" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Dodaj opis strony tutaj" />
<meta  name="keywords" content="Pierwsze słowo kluczowe, drugie słowo kluczowe" />
<?php $template_path = JURI::base() . 'templates/' . $app->getTemplate(); ?>
<?php JLoader::import( 'joomla.version' );
$version = new JVersion();
if (version_compare( $version->RELEASE, '2.5', '<=')) {
if(JFactory::getApplication()->get('jquery') !== true) {
$document = JFactory::getDocument();
JHtml::script(JURI::base() . "templates/". $app->getTemplate() ."/jquery.js");
}
} else {
JHtml::_('jquery.framework');
} ?>
<script type="text/javascript">
jQuery(document).ready(function(){
var inputs = document.getElementsByTagName('input');
for (a = 0; a < inputs.length; a++) {
if (inputs[a].type == "checkbox") {
var id = inputs[a].getAttribute("id");
if (id==null){
id=  "checkbox" +a;
}
inputs[a].setAttribute("id",id);
var container = document.createElement('div');
container.setAttribute("class", "ttr_checkbox");
var label = document.createElement('label');
label.setAttribute("for", id);
jQuery(inputs[a]).wrap(container).after(label);
}
}
});
</script>
<script type="text/javascript">
jQuery(document).ready(function(){
var inputs = document.getElementsByTagName('input');
for (a = 0; a < inputs.length; a++) {
if (inputs[a].type == "radio") {
var id = inputs[a].getAttribute("id");
if (id==null){
id=  "radio" +a;
}
inputs[a].setAttribute("id",id);
var container = document.createElement('div');
container.setAttribute("class", "ttr_radio");
var label = document.createElement('label');
label.setAttribute("for", id);
jQuery(inputs[a]).wrap(container).after(label);
}
}
});
</script>
<script type="text/javascript">
window.addEvent('domready', function() {
Element.implement({
hide: function() {
this.setStyle('display','');
}
});
});
</script>
<?php
if (version_compare( $version->RELEASE, '2.5', '<')) {
JHtml::_('jquery.ui');
}
$doc = JFactory::getDocument();
unset($this->_scripts[JURI::root(true).'/media/jui/js/bootstrap.min.js']);
 $doc->addScript(JURI::base() .'/templates/' . $this->template . '/bootstrap.min.js', 'text/javascript');
$doc->addStyleSheet('templates/'.$this->template.'/css/bootstrap.css');
$doc->addStyleSheet('templates/'.$this->template.'/css/template.css');
?>
<script type="text/javascript" src="<?php echo $template_path?>/totop.js">
</script>
<script type="text/javascript">
jQuery(document).ready(function(){
var window_height =  Math.max(document.documentElement.clientHeight, window.innerHeight || 0);
var body_height = jQuery(document.body).height();
var content = jQuery("#ttr_content_and_sidebar_container");
if(body_height < window_height){
differ = (window_height - body_height);
content_height = content.height() + differ;
jQuery("#ttr_content_and_sidebar_container").css("min-height", content_height+"px");
}
});
</script>
<script type="text/javascript">
jQuery(document).ready(function(){
jQuery('#nav-expander').on('click',function(e){
e.preventDefault();
jQuery('body').toggleClass('nav-expanded');
});
});
</script>
<script type="text/javascript">
jQuery(document).ready(function(){
jQuery('ul.ttr_menu_items.nav li [data-toggle=dropdown]').on('click', function() {
var window_width =  Math.max(document.documentElement.clientWidth, window.innerWidth || 0)
if(window_width > 1025){
window.location.href = jQuery(this).attr('href'); 
}
});
});
</script>
<script type="text/javascript">
jQuery(document).ready(function(){
jQuery('ul.ttr_vmenu_items.nav li [data-toggle=dropdown]').on('click', function() {
var window_width =  Math.max(document.documentElement.clientWidth, window.innerWidth || 0)
if(window_width > 1025){
window.location.href = jQuery(this).attr('href'); 
}
});
});
</script>
<script type="text/javascript">
jQuery(document).ready(function(){
jQuery('.ttr_menu_items ul.dropdown-menu [data-toggle=dropdown]').on('click', function(event) { 
var window_width =  Math.max(document.documentElement.clientWidth, window.innerWidth || 0);
if(window_width < 1025){
event.preventDefault();
event.stopPropagation();
jQuery(this).parent().siblings().removeClass('open');
jQuery(this).parent().toggleClass(function() {
if (jQuery(this).is(".open") ) {
window.location.href = jQuery(this).children("[data-toggle=dropdown]").attr('href'); 
return "";
} else {
return "open";
}
});
}
});
});
</script>
<script type="text/javascript">
jQuery(document).ready(function(){
jQuery('.ttr_vmenu_items ul.dropdown-menu [data-toggle=dropdown]').on('click', function(event) { 
var window_width =  Math.max(document.documentElement.clientWidth, window.innerWidth || 0);
if(window_width < 1025){
event.preventDefault();
event.stopPropagation();
jQuery(this).parent().siblings().removeClass('open');
jQuery(this).parent().toggleClass(function() {
if (jQuery(this).is(".open") ) {
window.location.href = jQuery(this).children("[data-toggle=dropdown]").attr('href'); 
return "";
} else {
return "open";
}
});
}
});
});
</script>
<script type="text/javascript">
jQuery(document).ready(function(){
var objects = ['iframe', 'video','object'];
for(var i = 0 ; i < objects.length ; i++){
if (jQuery(objects[i]).length > 0) {
jQuery(objects[i]).addClass('embed-responsive-item');
jQuery(objects[i]).parent().addClass('embed-responsive embed-responsive-16by9');
jQuery(".embed-responsive-16by9").css("padding-bottom","56.25%");
}
}
});
</script>
<script type="text/javascript">
WebFontConfig = {
google: { families: [ 'Lato','Lato'] }
};
(function() {
var wf = document.createElement('script');
wf.src = ('https:' == document.location.protocol ? 'https' : 'http') + '://ajax.googleapis.com/ajax/libs/webfont/1.0.31/webfont.js';
wf.type = 'text/javascript';
wf.async = 'true';
var s = document.getElementsByTagName('script')[0];
s.parentNode.insertBefore(wf, s);
})();
</script>
<link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/system/css/system.css" type="text/css" />
<!--[if lte IE 8]>
<link rel="stylesheet"  href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template; ?>/css/menuie.css" type="text/css"/>
<link rel="stylesheet"  href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template; ?>/css/vmenuie.css" type="text/css"/>
<![endif]-->
<script type="text/javascript" src="<?php echo $template_path?>/prefixfree.min.js">
</script>
<!--[if IE 7]>
<style type="text/css" media="screen">
#ttr_vmenu_items  li.ttr_vmenu_items_parent {display:inline;}
</style>
<![endif]-->
<!--[if lt IE 9]>
<script type="text/javascript" src="<?php echo $template_path?>/html5shiv.js">
</script>
<script type="text/javascript" src="<?php echo $template_path?>/respond.min.js">
</script>
<![endif]-->
</head>
<body>
<a href="#" class="back-to-top"><img alt="Back to Top" src="<?php echo $template_path?>/images/gototop.png"/></a>
<div class="ttr_banner_header">
<?php
if(  $this->countModules('HAModulePosition00')||  $this->countModules('HAModulePosition01')||  $this->countModules('HAModulePosition02')||  $this->countModules('HAModulePosition03')):
?>
<div class="ttr_banner_header_inner_above0">
<?php
$showcolumn= $this->countModules('HAModulePosition00');
?>
<?php if($showcolumn): ?>
<div class="cell1 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="headerabovecolumn1">
<jdoc:include type="modules" name="HAModulePosition00" style="<?php if(($this->params->get('hamoduleposition00') == 'block') || ($this->params->get('hamoduleposition00') == Null)): echo "block"; else: echo "xhtml"; endif;?>"/>
</div>
</div>
<?php else: ?>
<div class="cell1 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-xs-block">
</div>
<?php
$showcolumn= $this->countModules('HAModulePosition01');
?>
<?php if($showcolumn): ?>
<div class="cell2 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="headerabovecolumn2">
<jdoc:include type="modules" name="HAModulePosition01" style="<?php if(($this->params->get('hamoduleposition01') == 'block') || ($this->params->get('hamoduleposition01') == Null)): echo "block"; else: echo "xhtml"; endif;?>"/>
</div>
</div>
<?php else: ?>
<div class="cell2 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-sm-block visible-md-block visible-xs-block">
</div>
<?php
$showcolumn= $this->countModules('HAModulePosition02');
?>
<?php if($showcolumn): ?>
<div class="cell3 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="headerabovecolumn3">
<jdoc:include type="modules" name="HAModulePosition02" style="<?php if(($this->params->get('hamoduleposition02') == 'block') || ($this->params->get('hamoduleposition02') == Null)): echo "block"; else: echo "xhtml"; endif;?>"/>
</div>
</div>
<?php else: ?>
<div class="cell3 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-xs-block">
</div>
<?php
$showcolumn= $this->countModules('HAModulePosition03');
?>
<?php if($showcolumn): ?>
<div class="cell4 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="headerabovecolumn4">
<jdoc:include type="modules" name="HAModulePosition03" style="<?php if(($this->params->get('hamoduleposition03') == 'block') || ($this->params->get('hamoduleposition03') == Null)): echo "block"; else: echo "xhtml"; endif;?>"/>
</div>
</div>
<?php else: ?>
<div class="cell4 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-lg-block visible-sm-block visible-md-block visible-xs-block">
</div>
</div>
<?php endif; ?>
</div>
<div style="height:0px;width:0px;overflow:hidden;-webkit-margin-top-collapse: separate;"></div>
<header id="ttr_header">
<div id="ttr_header_inner">
<div class="innermenu"><div style="height:0px;width:0px;overflow:hidden;-webkit-margin-top-collapse: separate;"></div>
<?php if ($this->countModules('Menu')):?>
<nav id="ttr_menu" class="navbar-default navbar">
<div id="ttr_menu_inner_in">
<div class="menuforeground">
</div>
<div id="navigationmenu">
<div class="navbar-header">
<button id="nav-expander" data-target=".navbar-collapse" data-toggle="collapse" class="navbar-toggle" type="button">
<span class="sr-only">
</span>
<span class="icon-bar">
</span>
<span class="icon-bar">
</span>
<span class="icon-bar">
</span>
</button>
</div>
<div class="menu-center collapse navbar-collapse">
<jdoc:include type="modules" name="Menu"/>
</div>
</div>
</div>
</nav>
<?php endif; ?>

</div>
<a href="http://www.templatetoaster.com" class="headerforeground01">
</a>
<a href="http://www.templatetoaster.com" class="headerforeground02">
</a>
<?php if (($this->params->get('enable_site_Title')) || ($this->params->get('enable_site_Title') == Null)): ?>
<div class="ttr_title_position">
<?php $heading_tag = 'h3';
$temp = $this->params->get('Site_Title_Heading_Tag');
if($temp != Null)
$heading_tag = $temp;?>
<<?php echo $heading_tag; ?> class="ttr_title_style">
<a href="<?php echo $app->getCfg('live_site');?>" style="font-size:<?php echo $this->params->get('Site_Title_FontSize'); ?>px;color:<?php echo $this->params->get('site_title_color');?>">
<?php echo $this->params->get('Site_Title');?>
</a>
</<?php echo $heading_tag; ?>>
</div>
<?php endif; ?>
<?php if (($this->params->get('enable_site_slogan')) || ($this->params->get('enable_site_slogan') == Null)): ?>
<div class="ttr_slogan_position">
<?php $slogan_tag = 'h3';
$temp = $this->params->get('Site_Slogan_Heading_Tag');
if($temp != Null)
$slogan_tag = $temp;?>
<<?php echo $slogan_tag; ?> class="ttr_slogan_style"style="font-size:<?php echo $this->params->get('Site_Slogan_FontSize'); ?>px;color:<?php echo $this->params->get('site_slogan_color');?>">
<?php echo $this->params->get('Site_Slogan');?>
</div>
<?php endif; ?>
</div>
</header>
<div class="ttr_banner_header">
<?php
if(  $this->countModules('HBModulePosition00')||  $this->countModules('HBModulePosition01')||  $this->countModules('HBModulePosition02')||  $this->countModules('HBModulePosition03')):
?>
<div class="ttr_banner_header_inner_below0">
<?php
$showcolumn= $this->countModules('HBModulePosition00');
?>
<?php if($showcolumn): ?>
<div class="cell1 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="headerbelowcolumn1">
<jdoc:include type="modules" name="HBModulePosition00" style="<?php if(($this->params->get('hbmoduleposition00') == 'block') || ($this->params->get('hbmoduleposition00') == Null)): echo "block"; else: echo "xhtml"; endif;?>"/>
</div>
</div>
<?php else: ?>
<div class="cell1 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-xs-block">
</div>
<?php
$showcolumn= $this->countModules('HBModulePosition01');
?>
<?php if($showcolumn): ?>
<div class="cell2 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="headerbelowcolumn2">
<jdoc:include type="modules" name="HBModulePosition01" style="<?php if(($this->params->get('hbmoduleposition01') == 'block') || ($this->params->get('hbmoduleposition01') == Null)): echo "block"; else: echo "xhtml"; endif;?>"/>
</div>
</div>
<?php else: ?>
<div class="cell2 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-sm-block visible-md-block visible-xs-block">
</div>
<?php
$showcolumn= $this->countModules('HBModulePosition02');
?>
<?php if($showcolumn): ?>
<div class="cell3 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="headerbelowcolumn3">
<jdoc:include type="modules" name="HBModulePosition02" style="<?php if(($this->params->get('hbmoduleposition02') == 'block') || ($this->params->get('hbmoduleposition02') == Null)): echo "block"; else: echo "xhtml"; endif;?>"/>
</div>
</div>
<?php else: ?>
<div class="cell3 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-xs-block">
</div>
<?php
$showcolumn= $this->countModules('HBModulePosition03');
?>
<?php if($showcolumn): ?>
<div class="cell4 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="headerbelowcolumn4">
<jdoc:include type="modules" name="HBModulePosition03" style="<?php if(($this->params->get('hbmoduleposition03') == 'block') || ($this->params->get('hbmoduleposition03') == Null)): echo "block"; else: echo "xhtml"; endif;?>"/>
</div>
</div>
<?php else: ?>
<div class="cell4 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-lg-block visible-sm-block visible-md-block visible-xs-block">
</div>
</div>
<?php endif; ?>
</div>
<div id="ttr_page" class="container">
<div id="ttr_content_and_sidebar_container">
<?php
$showleft= $this->countModules('left');
?>
<?php if($showleft): ?>
<aside id="ttr_sidebar_left">
<div id="ttr_sidebar_left_margin">
<div style="height:0px;width:0px;overflow:hidden;-webkit-margin-top-collapse: separate;"></div>
<jdoc:include type="modules" name="left" style="block" /> 
<div style="height:0px;width:0px;overflow:hidden;-webkit-margin-top-collapse: separate;"></div>
</div>
</aside>
<?php endif; ?>
<?php
if($showleft){
?>
<div id="ttr_content">
<?php
}
else{
?>
<div id="ttr_content" class="zero_column" style="width:1150px">
<?php
}
?>
<div id="ttr_content_margin"class="container-fluid">
<div style="height:0px;width:0px;overflow:hidden;-webkit-margin-top-collapse: separate;"></div>
<?php
if(  $this->countModules('CAModulePosition00')||  $this->countModules('CAModulePosition01')||  $this->countModules('CAModulePosition02')||  $this->countModules('CAModulePosition03')):
?>
<div class="contenttopcolumn0">
<?php
$showcolumn= $this->countModules('CAModulePosition00');
?>
<?php if($showcolumn): ?>
<div class="cell1 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="topcolumn1">
<jdoc:include type="modules" name="CAModulePosition00" style="<?php if(($this->params->get('camoduleposition00') == 'block') || ($this->params->get('camoduleposition00') == Null)): echo "block"; else: echo "xhtml"; endif;?>"/>
</div>
</div>
<?php else: ?>
<div class="cell1 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-xs-block">
</div>
<?php
$showcolumn= $this->countModules('CAModulePosition01');
?>
<?php if($showcolumn): ?>
<div class="cell2 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="topcolumn2">
<jdoc:include type="modules" name="CAModulePosition01" style="<?php if(($this->params->get('camoduleposition01') == 'block') || ($this->params->get('camoduleposition01') == Null)): echo "block"; else: echo "xhtml"; endif;?>"/>
</div>
</div>
<?php else: ?>
<div class="cell2 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-sm-block visible-md-block visible-xs-block">
</div>
<?php
$showcolumn= $this->countModules('CAModulePosition02');
?>
<?php if($showcolumn): ?>
<div class="cell3 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="topcolumn3">
<jdoc:include type="modules" name="CAModulePosition02" style="<?php if(($this->params->get('camoduleposition02') == 'block') || ($this->params->get('camoduleposition02') == Null)): echo "block"; else: echo "xhtml"; endif;?>"/>
</div>
</div>
<?php else: ?>
<div class="cell3 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-xs-block">
</div>
<?php
$showcolumn= $this->countModules('CAModulePosition03');
?>
<?php if($showcolumn): ?>
<div class="cell4 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="topcolumn4">
<jdoc:include type="modules" name="CAModulePosition03" style="<?php if(($this->params->get('camoduleposition03') == 'block') || ($this->params->get('camoduleposition03') == Null)): echo "block"; else: echo "xhtml"; endif;?>"/>
</div>
</div>
<?php else: ?>
<div class="cell4 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-lg-block visible-sm-block visible-md-block visible-xs-block">
</div>
</div>
<?php endif; ?>
<jdoc:include type="message" style="width:100%;"/>
<jdoc:include type="component" />
<?php
if(  $this->countModules('CBModulePosition00')||  $this->countModules('CBModulePosition01')||  $this->countModules('CBModulePosition02')||  $this->countModules('CBModulePosition03')):
?>
<div class="contentbottomcolumn0">
<?php
$showcolumn= $this->countModules('CBModulePosition00');
?>
<?php if($showcolumn): ?>
<div class="cell1 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="bottomcolumn1">
<jdoc:include type="modules" name="CBModulePosition00" style="<?php if(($this->params->get('cbmoduleposition00') == 'block') || ($this->params->get('cbmoduleposition00') == Null)): echo "block"; else: echo "xhtml"; endif;?>"/>
</div>
</div>
<?php else: ?>
<div class="cell1 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-xs-block">
</div>
<?php
$showcolumn= $this->countModules('CBModulePosition01');
?>
<?php if($showcolumn): ?>
<div class="cell2 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="bottomcolumn2">
<jdoc:include type="modules" name="CBModulePosition01" style="<?php if(($this->params->get('cbmoduleposition01') == 'block') || ($this->params->get('cbmoduleposition01') == Null)): echo "block"; else: echo "xhtml"; endif;?>"/>
</div>
</div>
<?php else: ?>
<div class="cell2 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-sm-block visible-md-block visible-xs-block">
</div>
<?php
$showcolumn= $this->countModules('CBModulePosition02');
?>
<?php if($showcolumn): ?>
<div class="cell3 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="bottomcolumn3">
<jdoc:include type="modules" name="CBModulePosition02" style="<?php if(($this->params->get('cbmoduleposition02') == 'block') || ($this->params->get('cbmoduleposition02') == Null)): echo "block"; else: echo "xhtml"; endif;?>"/>
</div>
</div>
<?php else: ?>
<div class="cell3 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-xs-block">
</div>
<?php
$showcolumn= $this->countModules('CBModulePosition03');
?>
<?php if($showcolumn): ?>
<div class="cell4 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="bottomcolumn4">
<jdoc:include type="modules" name="CBModulePosition03" style="<?php if(($this->params->get('cbmoduleposition03') == 'block') || ($this->params->get('cbmoduleposition03') == Null)): echo "block"; else: echo "xhtml"; endif;?>"/>
</div>
</div>
<?php else: ?>
<div class="cell4 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-lg-block visible-sm-block visible-md-block visible-xs-block">
</div>
</div>
<?php endif; ?>
<div style="height:0px;width:0px;overflow:hidden;-webkit-margin-top-collapse: separate;"></div>
</div>
</div>
<div style="clear:both;">
</div>
</div>
<div class="footer-widget-area">
<div class="footer-widget-area_inner">
<?php
if(  $this->countModules('FAModulePosition00')||  $this->countModules('FAModulePosition01')||  $this->countModules('FAModulePosition02')||  $this->countModules('FAModulePosition03')):
?>
<div class="ttr_footer-widget-area_inner_above0">
<?php
$showcolumn= $this->countModules('FAModulePosition00');
?>
<?php if($showcolumn): ?>
<div class="cell1 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="footerabovecolumn1">
<jdoc:include type="modules" name="FAModulePosition00" style="<?php if(($this->params->get('famoduleposition00') == 'block') || ($this->params->get('famoduleposition00') == Null)): echo "block"; else: echo "xhtml"; endif;?>"/>
</div>
</div>
<?php else: ?>
<div class="cell1 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-xs-block">
</div>
<?php
$showcolumn= $this->countModules('FAModulePosition01');
?>
<?php if($showcolumn): ?>
<div class="cell2 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="footerabovecolumn2">
<jdoc:include type="modules" name="FAModulePosition01" style="<?php if(($this->params->get('famoduleposition01') == 'block') || ($this->params->get('famoduleposition01') == Null)): echo "block"; else: echo "xhtml"; endif;?>"/>
</div>
</div>
<?php else: ?>
<div class="cell2 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-sm-block visible-md-block visible-xs-block">
</div>
<?php
$showcolumn= $this->countModules('FAModulePosition02');
?>
<?php if($showcolumn): ?>
<div class="cell3 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="footerabovecolumn3">
<jdoc:include type="modules" name="FAModulePosition02" style="<?php if(($this->params->get('famoduleposition02') == 'block') || ($this->params->get('famoduleposition02') == Null)): echo "block"; else: echo "xhtml"; endif;?>"/>
</div>
</div>
<?php else: ?>
<div class="cell3 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-xs-block">
</div>
<?php
$showcolumn= $this->countModules('FAModulePosition03');
?>
<?php if($showcolumn): ?>
<div class="cell4 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="footerabovecolumn4">
<jdoc:include type="modules" name="FAModulePosition03" style="<?php if(($this->params->get('famoduleposition03') == 'block') || ($this->params->get('famoduleposition03') == Null)): echo "block"; else: echo "xhtml"; endif;?>"/>
</div>
</div>
<?php else: ?>
<div class="cell4 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-lg-block visible-sm-block visible-md-block visible-xs-block">
</div>
</div>
<?php endif; ?>
</div>
</div>
<div style="height:0px;width:0px;overflow:hidden;-webkit-margin-top-collapse: separate;"></div>
<footer id="ttr_footer">
<div id="ttr_footer_top_for_widgets">
<div class="ttr_footer_top_for_widgets_inner">
<?php 
if($this->countModules('LeftFooterArea') || $this->countModules('CenterFooterArea') || $this->countModules('RightFooterArea')):
?>
<div class="footer-widget-area_fixed">
<div style="margin:0 auto;">
<?php if($this->countModules('LeftFooterArea')): ?>
<div id="first" class="widget-area">
<jdoc:include type="modules" name="LeftFooterArea" style="<?php if(($this->params->get('leftfooterarea') == 'block') || ($this->params->get('leftfooterarea') == Null)): echo "block"; else: echo "xhtml"; endif;?>"/>
</div>
<?php else: ?>
<div id="first" class="widget-area">
&nbsp;
</div>
<?php endif; ?>
<?php if($this->countModules('CenterFooterArea')): ?>
<div id="second" class="widget-area">
<jdoc:include type="modules" name="CenterFooterArea" style="<?php if(($this->params->get('centerfooterarea') == 'block') || ($this->params->get('centerfooterarea') == Null)): echo "block"; else: echo "xhtml"; endif;?>"/>
</div>
<?php else: ?>
<div id="second" class="widget-area">
&nbsp;
</div>
<?php endif; ?>
<?php if($this->countModules('RightFooterArea')): ?>
<div id="third" class="widget-area">
<jdoc:include type="modules" name="RightFooterArea" style="<?php if(($this->params->get('rightfooterarea') == 'block') || ($this->params->get('rightfooterarea') == Null)): echo "block"; else: echo "xhtml"; endif;?>"/>
</div>
<?php else: ?>
<div id="third" class="widget-area">
&nbsp;
</div>
<?php endif; ?>
</div>
</div>
<?php endif; ?>
</div>
</div>
<div class="ttr_footer_bottom_footer">
<div class="ttr_footer_bottom_footer_inner">
<?php if (($this->params->get('enable_Copyright_Text')) || ($this->params->get('enable_Copyright_Text') == Null)): ?>
<div id="ttr_copyright">
<a style=" font-size:<?php echo $this->params->get('Copyright_FontSize'); ?>px;color:<?php echo $this->params->get('footer_copyright_color');?>" <?php if ($this->params->get('Copyright_Url')): ?> href="<?php echo $this->params->get('Copyright_Url');?>" <?php else: ?> href="<?php echo $app->getCfg('live_site');?>" <?php endif; ?>>
<?php $copy = 'Copyright@example.com';
$temp = $this->params->get('Copyright_Text');
if($temp != Null)
$copy = $temp;
echo $copy; ?>
</a>
</div>
<?php endif; ?>
<?php if (($this->params->get('enable_Designed_By')) || ($this->params->get('enable_Designed_By') == Null)): ?>
<div id="ttr_footer_designed_by_links">
<a <?php if ($this->params->get('Designed_By')): ?> href="<?php echo $this->params->get('Designed_By');?>"<?php else: ?> href="<?php echo $app->getCfg('live_site');?>"<?php endif; ?> style="font-size:<?php echo $this->params->get('Designed_By_Link_FontSize'); ?>px;color:<?php echo $this->params->get('footer_designed_by_link_color');?>">
Joomla Template
</a>
<span id="ttr_footer_designed_by" style="font-size:<?php echo $this->params->get('Designed_By_FontSize'); ?>px;color:<?php echo $this->params->get('footer_designed_by_color');?>">
Designed With TemplateToaster
</span>
</div>
<?php endif; ?>
</div>
</div>
</footer>
<div style="height:0px;width:0px;overflow:hidden;-webkit-margin-top-collapse: separate;"></div>
<div class="footer-widget-area">
<div class="footer-widget-area_inner">
<?php
if(  $this->countModules('FBModulePosition00')||  $this->countModules('FBModulePosition01')||  $this->countModules('FBModulePosition02')||  $this->countModules('FBModulePosition03')):
?>
<div class="ttr_footer-widget-area_inner_below0">
<?php
$showcolumn= $this->countModules('FBModulePosition00');
?>
<?php if($showcolumn): ?>
<div class="cell1 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="footerbelowcolumn1">
<jdoc:include type="modules" name="FBModulePosition00" style="<?php if(($this->params->get('fbmoduleposition00') == 'block') || ($this->params->get('fbmoduleposition00') == Null)): echo "block"; else: echo "xhtml"; endif;?>"/>
</div>
</div>
<?php else: ?>
<div class="cell1 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-xs-block">
</div>
<?php
$showcolumn= $this->countModules('FBModulePosition01');
?>
<?php if($showcolumn): ?>
<div class="cell2 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="footerbelowcolumn2">
<jdoc:include type="modules" name="FBModulePosition01" style="<?php if(($this->params->get('fbmoduleposition01') == 'block') || ($this->params->get('fbmoduleposition01') == Null)): echo "block"; else: echo "xhtml"; endif;?>"/>
</div>
</div>
<?php else: ?>
<div class="cell2 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-sm-block visible-md-block visible-xs-block">
</div>
<?php
$showcolumn= $this->countModules('FBModulePosition02');
?>
<?php if($showcolumn): ?>
<div class="cell3 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="footerbelowcolumn3">
<jdoc:include type="modules" name="FBModulePosition02" style="<?php if(($this->params->get('fbmoduleposition02') == 'block') || ($this->params->get('fbmoduleposition02') == Null)): echo "block"; else: echo "xhtml"; endif;?>"/>
</div>
</div>
<?php else: ?>
<div class="cell3 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-xs-block">
</div>
<?php
$showcolumn= $this->countModules('FBModulePosition03');
?>
<?php if($showcolumn): ?>
<div class="cell4 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="footerbelowcolumn4">
<jdoc:include type="modules" name="FBModulePosition03" style="<?php if(($this->params->get('fbmoduleposition03') == 'block') || ($this->params->get('fbmoduleposition03') == Null)): echo "block"; else: echo "xhtml"; endif;?>"/>
</div>
</div>
<?php else: ?>
<div class="cell4 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-lg-block visible-sm-block visible-md-block visible-xs-block">
</div>
</div>
<?php endif; ?>
</div>
</div>
</div>
</div>
<?php if ($this->countModules('debug')){ ?>
<jdoc:include type="modules" name="debug" style="<?php if(($this->params->get('debug') == 'block') || ($this->params->get('debug') == Null)): echo "block"; else: echo "xhtml"; endif;?>"/>
<?php } ?>
</body>
</html>
