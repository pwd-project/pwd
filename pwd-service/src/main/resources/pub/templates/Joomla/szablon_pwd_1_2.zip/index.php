<?php

// No direct access.
defined('_JEXEC') or die;

JLoader::import('joomla.filesystem.file');

JHtml::_('behavior.framework', true);
?>
<!DOCTYPE html>
<html><head>
			
			<jdoc:include type="head" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Lato:400,700&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="templates/szablon_pwd_1_2/files/style.css?1449557702" type="text/css" media="screen, projection">
	
	<script type="text/javascript" src="templates/szablon_pwd_1_2/files/scripts.js?ver=0.1449558269"></script>
	<script type="text/javascript" src="templates/szablon_pwd_1_2/files/materialize.min.js"></script>
	
</head>
<body class="default_styling">
	<div class="navbar-fixed">
    	<nav class="top_nav">
            <div class="custom_container"> 
          		<div class="nav-wrapper">
            		<a href="#" data-activates="mobile-demo" class="button-collapse black-text"><i class="material-icons">menu</i></a>
            		<ul class="hide-on-med-and-down">
            			<li class="left pwd_logo"><img src="templates/szablon_pwd_1_2/files/pwd_logo.png" alt="logo"></li>
              		    
            		</ul>
                    <ul class="">
                        <li class="right contrast"><span class="con_op_4">A</span></li>
                        <li class="right contrast"><span class="con_op_3">A</span></li>
                        <li class="right contrast"><span class="con_op_2">A</span></li>
                        <li class="right contrast"><span class="con_op_1">A</span></li>
                        <li class="right fontsize higher_size">A<span class="igorny">++</span></li>
                        <li class="right fontsize medium_size">A<span class="igorny">+</span></li>
                        <li class="right fontsize default_size">A</li>
                    </ul>
            		<ul class="side-nav black-text" id="mobile-demo" style="left: -250px;">
                        <li><img src="templates/szablon_pwd_1_2/files/pwd_logo.png" alt="logo"></li>
                        <div class="menu">
							<jdoc:include type="modules" name="position-7" />
						<!-- <ul><li class="page_item page-item-2"><a href="about">About</a></li></ul> -->
						</div>
 
          			</ul>
          		</div>
            </div>
    	</nav>
  	</div>
  	<div class="custom_container">
        <div class="row no_m_b main_content_page">
  		    <div class="col m12 l3 s12 white main_left_col">
  		    	<div class="lef_col_faker_width" style="height: 875px;"></div>
  			    <div class="row bip_main_logo">
  				   <a href="/"> <img src="templates/szablon_pwd_1_2/files/logo_bip.png" alt="" class="center-image" style=" margin-left:0.75rem;   max-width: 80%;"></a>
  			    </div>
  			    <div class="row">
  			    	<div class="col s12 m12 l12">
              <div style="width:100%; display:block; line-height:2rem;">
				<jdoc:include type="modules" name="position-1" />
              </div>
            		</div>
  				</div>
  				<div class="row side_menu_left">
					<jdoc:include type="modules" name="position-4" style="xhtml" />
  				</div>
  			</div>
        	<div class="col m12 l9 s12 no_p_l no_p_r">
          		<div class="row no_m_b">
            		<div class="col s12 m12 l12 no_p_l no_p_r">
  						<div class="image_holder">
  							<img src="templates/szablon_pwd_1_2/files/baner.jpg" alt="baner">
  							<div class="menu_image">
	  							<ul class="text-uppercase">
		  							<div class="menu"><!-- <ul><li class="page_item page-item-2"><a href="about/">About</a></li></ul> -->
										<jdoc:include type="modules" name="position-7" />
									</div>
 
	  							</ul>
  							</div>
  						</div>
  					</div>
  				</div>  				<div class="row no_m_b">
  					<div class="col s12 m12 l12 no_p_r">
						<jdoc:include type="modules" name="position-2" />
  						<div class="right_col_content">
  						
  						<div class="main_content_box">
                                        
  							
  							<div class="right_col_content1">
								<jdoc:include type="component" /> 
  						</div>
  					</div>
  				</div>
  			</div>
        </div>
  	</div>
</div>
</div>
<div class="footer">
    <div class="custom_container stopka">
        <div style="color:#333333;" class="">
          	<div class="row no_m_b">
            	<div class="col m6 l6 s12">
              		Strona została opracowana w ramach projektu PWD online realizowanego przez Stowarzyszenie Na Rzecz Rozwoju Regionu Dolina Gubra przy wsparciu Ministerstwa Administracji i Cyfryzacji
            	</div>
            	<div class="col m6 l6 s12">
                  <img src="templates/szablon_pwd_1_2/files/maic.png" class="right" alt="maic">
              		<img src="templates/szablon_pwd_1_2/files/gubra.png" class="right" alt="gubra">
            	</div>
          	</div>
        </div>
      </div>
    </div>
<div class="hiddendiv common"></div><div class="drag-target" style="left: 0px; touch-action: pan-y; -webkit-user-drag: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></div></body></html>