jQuery(document).ready(function() {

		jQuery('[data-toggle="tooltip"]').tooltip(); 
		jQuery(window).on("keydown", this, function (event) {
			if (event.keyCode == 116) {
				Cookies.remove('style');
			}
		});
		var plus = 0;
		jQuery('.font-basic').click(function() {
			jQuery('p, span, h1, h2, h3, h4, h5:not(".rank-value"), h6, ul, li, td, th, a, .camera_caption_title, label').removeAttr('style');
			plus=0;
		});
		jQuery('.font-plus').click(function() {
			jQuery('p, span, h1, h2, h3, h4, h5:not(".rank-value"), h6, ul, li, td, th, a, .camera_caption_title, label').removeAttr('style');
			jQuery('p, .section span, h1, h2, h3, h4, h5:not(".rank-value"), h6, ul, li, td, th, a, .camera_caption_title, label').css("font-size", function() {
				plus=plus+1;
				return parseInt(jQuery(this).css('font-size')) * 1.5 + 'px';		
			});
		});
		jQuery('.font-plus-plus').click(function() {
			jQuery('p,  span, h1, h2, h3, h4, h5:not(".rank-value"), h6, ul, li, td, th, a, .camera_caption_title, label').removeAttr('style');
			jQuery('p, .section span, h1, h2, h3, h4, h5:not(".rank-value"), h6, ul, li, td, th, a, .camera_caption_title, label').css("font-size", function() {
				
				return parseInt(jQuery(this).css('font-size')) * 2 + 'px';		
			});
		
		});

		jQuery('.contrast-1').click(function() {
			jQuery('.rank-ico').attr('src','/img/rank.png');
			jQuery('.visible-regular').show();
			jQuery('.visible-contrast').hide();
			jQuery('#contrast-style').remove();
			Cookies.set('style', '1');
		});
		jQuery('.contrast-2').click(function() {
			jQuery('.rank-ico').attr('src','/img/rank-white.png');
			jQuery('.visible-contrast').show();
			jQuery('.visible-regular').hide();
			jQuery('#contrast-style').remove();
			jQuery('head').append('<link id="contrast-style" rel="stylesheet" href="/templates/szablon_pwd_3_1/files/contrast-2.css" type="text/css" />');
			Cookies.set('style', '2');
		});
		jQuery('.contrast-3').click(function() {
			jQuery('.rank-ico').attr('src','/img/rank.png');
			jQuery('.visible-contrast').show();
			jQuery('.visible-regular').hide();
			jQuery('#contrast-style').remove();
			jQuery('head').append('<link id="contrast-style" rel="stylesheet" href="/templates/szablon_pwd_3_1/files/contrast-3.css" type="text/css" />');
			Cookies.set('style', '3');
		});
		jQuery('.contrast-4').click(function() {
			jQuery('.rank-ico').attr('src','/img/rank-yellow.png');
			jQuery('.visible-contrast').show();
			jQuery('.visible-regular').hide();
			jQuery('#contrast-style').remove();
			jQuery('head').append('<link id="contrast-style" rel="stylesheet" href="/templates/szablon_pwd_3_1/files/contrast-4.css" type="text/css" />');
			Cookies.set('style', '4');
		});
		
		var style = Cookies.get('style');
		if(style == 1){
			jQuery('#contrast-style').remove();
			jQuery('.rank-ico').attr('src','/img/rank.png');
		}
		else if(style == 2){
			jQuery('.rank-ico').attr('src','/img/rank-white.png');
			jQuery('head').append('<link id="contrast-style" rel="stylesheet" href="/templates/szablon_pwd_3_1/files/contrast-'+style+'.css" type="text/css" />');
		}
		else if(style == 3){
			jQuery('.rank-ico').attr('src','/img/rank.png');
			jQuery('head').append('<link id="contrast-style" rel="stylesheet" href="/templates/szablon_pwd_3_1/files/contrast-'+style+'.css" type="text/css" />');
		}
		else if(style == 4){
			jQuery('.rank-ico').attr('src','/img/rank-yellow.png');
			jQuery('head').append('<link id="contrast-style" rel="stylesheet" href="/templates/szablon_pwd_3_1/files/contrast-'+style+'.css" type="text/css" />');
		}
		
		
	});