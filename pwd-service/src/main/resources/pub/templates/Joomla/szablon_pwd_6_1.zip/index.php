<?php

// No direct access.
defined('_JEXEC') or die;

JLoader::import('joomla.filesystem.file');

JHtml::_('behavior.framework', true);
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>" >
<head>
 <title></title>
	<meta charset="UTF-8">
	<jdoc:include type="head" />
	<link href="https://fonts.googleapis.com/css?family=Roboto+Slab:400,700,300" rel="stylesheet" type="text/css">
	<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
	<link href="https://fonts.googleapis.com/css?family=Roboto:400,300" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato:400,700,300" rel="stylesheet" type="text/css">
	<link rel="stylesheet" href="templates/szablon_pwd_6_1/files/style.css" type="text/css" media="screen, projection">
	<script src="templates/szablon_pwd_6_1/files/cookies.js"></script>
  <script type="text/javascript" src="templates/szablon_pwd_6_1/files/scripts.min.js?ver=0.1449652243"></script>
</head>
<body class="default_colors">
<div class="custom_container">
	<div class="navbar-fixed top-nav">
    	<nav>
      	<div class="nav-wrapper custom_sub_contaier">
        	<a href="/" class="brand-logo"><img src="templates/szablon_pwd_6_1/files/top-nav-pwdlogo.png" alt="pwdlogo"></a>
        	<ul class="left hide-on-med-and-down">
          		<li><a href="sass.html">Dostępność PWD 100%</a></li>
        	</ul>
        	<ul class="right hide-on-med-and-down contrasts">
          		<li id="cont_1" class="still_same">A</li>
          		<li id="cont_2" class="still_same">A</li>
          		<li id="cont_3" class="still_same">A</li>
          		<li id="cont_4" class="still_same">A</li>
        	</ul>        	
        	<ul class="right hide-on-med-and-down font_sizes">
          		<li class="1_size font-basic still_same">A</li>
          		<li class="2_size font-plus still_same">A<span>+</span></li>
          		<li class="3_size font-plus-plus still_same">A<span>++</span></li>
        	</ul>
      	</div>
    	</nav>
  	</div>
  	<div class="first_page" style="min-height: 570px;">
  		<img src="templates/szablon_pwd_6_1/files/main_bg.jpg" alt="main_bg" class="bg_img">
  		<div class="navbar-fixed">
    		<nav>
      			<div class="nav-wrapper custom_sub_contaier">
        			<a href="/" class="brand-logo"><img src="templates/szablon_pwd_6_1/files/fundacja_logo.png" alt="pwdlogo"></a>
        			<ul class="right hide-on-med-and-down">
                        <div class="menu"><!-- <ul><li class="page_item page-item-2"><a href="about/">About</a></li></ul> -->
							<jdoc:include type="modules" name="position-7" />
						</div>
 
        		      </ul>
      			</div>
    		</nav>
  		</div>
  		<div class="custom_sub_contaier">
  			<div class="slogan">Wspieramy potrzebujących</div>
      		<p class="slogan_min">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Odio iste deleniti nesciunt unde, corrupti officia corporis, at vitae odit enim expedita quibusdam tempora eligendi. Ducimus asperiores ipsum numquam, quis sequi!</p>
			<div id="przyciski"><jdoc:include type="modules" name="position-3" />
      		 <!-- <a href="" class="see_projects">Zobacz nasze projekty</a>
      		<a href="" class="about_us_a">O nas</a>  -->
			</div>
  		</div>
  	</div>
    <div class="main_page_posts">
        <div class="custom_sub_contaier">
            <div class="row">
				<jdoc:include type="message" /><jdoc:include type="component"  />
            </div>
        </div>
    </div>
    <div class="three_cards_segment">
        <div class="custom_sub_contaier">
            <div class="row">
                <div class="col s12 m4 l4">
                    <div class="card_content">
						<div class="title_number">1</div>
						<jdoc:include type="modules" name="card1" style="xhtml" />
                        <!-- <div class="card_title">
						
                            <div class="title_text">
                                Lorem ipsum dolor sit amet, consectetur.
                            </div>
                            
                        </div>
                        <p>
                            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Harum aliquam vitae saepe nam ratione cupiditate laudantium, fugiat sit consequuntur distinctio pariatur vero provident. 
                        </p> -->
                        <img src="templates/szablon_pwd_6_1/files/three_cards_img_1.jpg" alt="three_cards_img_1">
                    </div>
                </div>
                <div class="col s12 m4 l4">
                    <div class="card_content">
						<div class="title_number">2</div>
						<jdoc:include type="modules" name="card2" style="xhtml" />
                        <!-- <div class="card_title">
                            <div class="title_text">
                                Lorem ipsum dolor sit amet, consectetur.
                            </div>
                            
                        </div>
                        <p>
                            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Harum aliquam vitae saepe nam ratione cupiditate laudantium, fugiat sit consequuntur distinctio pariatur vero provident. 
                        </p> -->
                        <img src="templates/szablon_pwd_6_1/files/three_cards_img_2.jpg" alt="three_cards_img_2">
                    </div>                    
                </div> 
                <div class="col s12 m4 l4">
                    <div class="card_content">
						<div class="title_number">3</div>
						<jdoc:include type="modules" name="card2" style="xhtml" />
                        <!-- <div class="card_title">
                            <div class="title_text">
                                Lorem ipsum dolor sit amet, consectetur.
                            </div>
                            
                        </div>
                        <p>
                            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Harum aliquam vitae saepe nam ratione cupiditate laudantium, fugiat sit consequuntur distinctio pariatur vero provident. 
                        </p> -->
                        <img src="templates/szablon_pwd_6_1/files/three_cards_img_3.jpg" alt="three_cards_img_3">
                    </div>                    
                </div>
            </div>
        </div>
    </div>
    <div class="main_page_text">
        <div class="custom_sub_contaier">
			<jdoc:include type="modules" name="position-8" style="xhtml" />
            <!-- <h5>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</h5>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Explicabo corporis voluptas laboriosam dicta delectus asperiores sed minima distinctio, accusantium ab velit modi eligendi, cum hic laudantium debitis earum. Eum error vel corrupti provident quaerat maiores tempora, ad placeat obcaecati itaque.</p>
            <p>Quam aut placeat quibusdam reiciendis molestiae fugit. Autem sapiente dolorum sit, dolores veritatis a rerum maiores. Tenetur dignissimos voluptatum officiis vel enim fugit, porro laborum velit. Nisi aut quo error, tempore. Mollitia natus voluptas ipsa, dignissimos reprehenderit animi ducimus ab.</p> -->
        </div>
    </div>
    <div class="footer">
        <div class="custom_sub_contaier">    
        <div class="row">
            <div class="col s12 m7 l7">
                <p>Szablon został opracowany w ramach projektu PWD Online prowadzonego przez Stowarzyszenie Na Rzecz
					Rozwoju Regionu Dolina Gubra i Ministerstwo Administracji i Cyfryzacji <a href="http://pwd.dolinagubra.pl">pwd.dolinagubra.pl</a>
				</p>
            </div>
            <div class="col s12 m5 l5 footer_logos">
                <img src="templates/szablon_pwd_6_1/files/godlo.png" alt="maic">
                <img src="templates/szablon_pwd_6_1/files/dolina.png" alt="dolina">

            </div>
        </div>

        </div>        
    </div>
</div>

<div class="hiddendiv common"></div></body></html>