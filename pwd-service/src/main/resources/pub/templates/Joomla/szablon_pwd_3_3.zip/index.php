<?php

// No direct access.
defined('_JEXEC') or die;

JLoader::import('joomla.filesystem.file');

JHtml::_('behavior.framework', true);
?>
<!DOCTYPE html>
<html  >
<head>
<jdoc:include type="head" />
      <link rel="stylesheet" href="templates/szablon_pwd_3_3/files/style.css" type="text/css" media="screen, projection">
<link type="text/css" rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans" media="all">
<link type="text/css" rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto&amp;subset=latin,latin-ext" media="all">
		
<script type="text/javascript" src="templates/szablon_pwd_3_3/files/skrypt.js"></script>
<script type="text/javascript" src="templates/szablon_pwd_3_3/files/slider.js"></script>
<script type="text/javascript" src="templates/szablon_pwd_3_3/files/bootstrap.js"></script>
<script type="text/javascript" src="templates/szablon_pwd_3_3/files/js.cookie.js"></script>

    </head>
    <body class="html front not-logged-in one-sidebar sidebar-first page-node">

<div id="wrapper">
<div class="icons">
	<span class="font font-basic" title="Podstawowy rozmiar tekstu">
	A
	</span>
	<span class="font font-plus" title="Powiększ tekst o 50%">
	A<em>+</em>
	</span>
	<span class="font font-plus-plus" title="Powiększ tekst o 100%">
	A<em>++</em>
	</span>
	
	<span class="contrast contrast-1" title="Podstawowy kontrast">
	K
	</span>
	<span class="contrast contrast-2" title="Biały tekst na czarnym tle">
	K
	</span>
	<span class="contrast contrast-3" title="Czarny tekst na źółtym tle">
	K
	</span>
	<span class="contrast contrast-4" title="Żółty tekst na czarnym tle">
	K
	</span>
</div>
<div class="clear"></div>  
  
  <!-- Header Starts -->
  <div id="header" class="clearfix">
    	<img class="img-responsive" typeof="foaf:Image" src="templates/szablon_pwd_3_3/files/logo.jpg" alt="">    <!-- navigation START -->
	<nav class="navbar navbar-default">
		<div class="container-fluid">
			<!-- Brand and toggle get grouped for better mobile display -->
			<div class="navbar-header">
			  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
				<span class="sr-only">Pokaż/Ukryj nawigacje</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			  </button>
			</div>
		</div>
		<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			<jdoc:include type="modules" name="position-7" style="xhtml" />
			<!-- <ul class="nav navbar-nav"><li class="first last leaf"><a href="/drupal/" class="active">Home</a></li>
</ul>			 --><div id="top-triangle"></div>
			<div id="bottom-triangle"></div>
				<div class="szukaj"><jdoc:include type="modules" name="position-1" style="xhtml" /></div>
						<!-- socialbar Starts -->
						<div id="socialbar">
			<ul class="social">
						<li class="fb"><a href="http://www.facebook.com/test" target="_blank">facebook</a></li> 			<li class="tw"><a href="https://twitter.com/test" target="_blank">twitter</a></li> 			<li class="ln"><a href="http://in.linkedin.com/in/asdf" target="_blank">linkedin</a></li> 			</ul>
			</div>
						<!-- socialbar Ends -->
		</div>
	</nav>

  </div>
  <!-- Header Ends -->

  
  
    <div class="clear"></div>
	<div class="container padding-none">
      <a id="main-content"></a>
	  <div class="col-md-3 padding-none">
	        <div id="sidebar" class="sidebar clearfix">
				<div id="menu-boczne"><jdoc:include type="modules" name="position-3" style="xhtml" /></div>
              <div class="region region-sidebar-first">
				            <jdoc:include type="modules" name="position-5" style="xhtml" />
    </div>
   <!-- /.region -->
		
						<div class="col-md-12 link-group padding-none">
							<jdoc:include type="modules" name="position-6" style="xhtml" />
			</div>
					
      </div>  <!-- /#sidebar-first -->
	        
	  </div>
	  
	  <div class="col-md-9">
			<jdoc:include type="modules" name="slider" />

	<div class="col-md-12  bip">
		<div class="col-md-6">
			<a href="http://google.pl" target="_blank"><img src="templates/szablon_pwd_3_3/files/link4.png" alt="Lorem ipsum"></a>
			<a href="http://google.pl" target="_blank">Lorem ipsum</a>
			<p>Lorem ipsum</p>
		</div>
		<div class="col-md-6">
			<a href="http://google.pl" target="_blank"><img src="templates/szablon_pwd_3_3/files/link5.png" alt="Lorem ipsum"></a>
			<a href="http://google.pl" target="_blank">Lorem ipsum</a>
			<p>Lorem ipsum</p>
		</div>
	</div>
	<div class="clear"></div>
            <div class="region region-content">
      <div id="block-system-main" class="block block-system">

      <jdoc:include type="message" /><jdoc:include type="component"  />
  
  
</div> <!-- /.block -->
    </div>
   <!-- /.region -->
      
	  </div>

    </div></div> <!-- /.section, /#content -->
  
  
  <!--Footer context Start -->
 <footer>
    <div class="container">
		<div class="row">
			<div class="col-md-7">
				<p>Szablon został opracowany w ramach projektu PWD Online prowadzonego przez Stowarzyszenie Na Rzecz
					Rozwoju Regionu Dolina Gubra i Ministerstwo Administracji i Cyfryzacji <a href="http://pwd.dolinagubra.pl">pwd.dolinagubra.pl</a>
				</p>
			</div>
			<div class="col-md-5">	
				<img src="templates/szablon_pwd_3_3/files/maic.png" alt="Ministerstwo Administracji i Cyfryzacji" class="img-responsive pull-right maic">
				<img src="templates/szablon_pwd_3_3/files/dolina-gubra-logo-stopka.svg" class="img-responsive pull-right" alt="Dolina Gubra">
			</div>
		</div>
    </div>
</footer>
  <!--Footer context Ends -->
  <div class="clear"></div>

          
  
<script id="hiddenlpsubmitdiv" style="display: none;"></script><script>try{(function() { for(var lastpass_iter=0; lastpass_iter < document.forms.length; lastpass_iter++){ var lastpass_f = document.forms[lastpass_iter]; if(typeof(lastpass_f.lpsubmitorig2)=="undefined"){ lastpass_f.lpsubmitorig2 = lastpass_f.submit; if (typeof(lastpass_f.lpsubmitorig2)=='object'){ continue;}lastpass_f.submit = function(){ var form=this; var customEvent = document.createEvent("Event"); customEvent.initEvent("lpCustomEvent", true, true); var d = document.getElementById("hiddenlpsubmitdiv"); if (d) {for(var i = 0; i < document.forms.length; i++){ if(document.forms[i]==form){ if (typeof(d.innerText) != 'undefined') { d.innerText=i.toString(); } else { d.textContent=i.toString(); } } } d.dispatchEvent(customEvent); }form.lpsubmitorig2(); } } }})()}catch(e){}</script></body></html>