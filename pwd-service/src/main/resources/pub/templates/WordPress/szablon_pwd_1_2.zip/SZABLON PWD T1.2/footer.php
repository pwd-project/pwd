        </div>
  	</div>
</div>
<div class="footer">
    <div class="custom_container">
        <div style="color:#333333;" class="">
          	<div class="row no_m_b">
            	<div class="col m6 l6 s12">
              		Strona została opracowana w ramach projektu PWD online realizowanego przez Stowarzyszenie Na Rzecz Rozwoju Regionu Dolina Gubra przy wsparciu Ministerstwa Administracji i Cyfryzacji
            	</div>
            	<div class="col m6 l6 s12">
              		<img src="<?php bloginfo('stylesheet_directory'); ?>/img/maic.png" class="right" alt="maic">
                  <img src="<?php bloginfo('stylesheet_directory'); ?>/img/gubra.png" class="right" alt="gubra">
            	</div>
          	</div>
        </div>
      </div>
    </div>
</body>
</html>