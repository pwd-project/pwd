<?php


get_header(); ?>

    <div class="first_page updates_page">
          <nav>
              <div class="nav-wrapper custom_sub_contaier">
                <a href="/" class="brand-logo"><img src="<?php bloginfo('stylesheet_directory'); ?>/img/fundacja_logo.png" alt="pwdlogo"></a>
                <ul class="right hide-on-med-and-down">
<?php wp_nav_menu( array('menu'=>'Fundacja 1 menu main') ); ?> 
                </ul>
              </div>
          </nav>
    </div>
        <div class="updates_page_content">
        <div class="custom_sub_contaier">
    <?php
    // Start the loop.
    while ( have_posts() ) : the_post();

      // Include the page content template.
      get_template_part( 'content', 'page' );

      // If comments are open or we have at least one comment, load up the comment template.
      if ( comments_open() || get_comments_number() ) :
        comments_template();
      endif;

    // End the loop.
    endwhile;
    ?>
</div></div>

<?php get_footer(); ?>
