<?php
get_header(); ?>

  	<div class="first_page updates_page">
    			<nav>
      				<div class="nav-wrapper custom_sub_contaier">
        				<a href="/" class="brand-logo"><img src="<?php bloginfo('stylesheet_directory'); ?>/img/fundacja_logo.png" alt="pwdlogo"></a>
        				<ul class="right hide-on-med-and-down">
<?php wp_nav_menu( array('menu'=>'Fundacja 1 menu main') ); ?>
        				</ul>
      				</div>
    			</nav>
  	</div>
  	    <div class="updates_page_content">
        <div class="custom_sub_contaier">
		<?php if ( have_posts() ) : ?>


			<?php
			// Start the Loop.
			while ( have_posts() ) : the_post();

				/*
				 * Include the Post-Format-specific template for the content.
				 * If you want to override this in a child theme, then include a file
				 * called content-___.php (where ___ is the Post Format name) and that will be used instead.
				 */
				get_template_part( 'content', 'search' );

			// End the loop.
			endwhile;

			// Previous/next page navigation.

		// If no content, include the "No posts found" template.
		else :
			get_template_part( 'content', 'none' );

		endif;
		?>

</div></div>
<?php get_footer(); ?>
