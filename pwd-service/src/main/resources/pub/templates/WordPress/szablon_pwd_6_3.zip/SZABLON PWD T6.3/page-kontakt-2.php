<?php get_header(); ?>
<div class="first_page updates_page">
    <nav>
        <div class="nav-wrapper custom_sub_contaier">
            <a href="/" class="brand-logo"><img src="<?php bloginfo('stylesheet_directory'); ?>/img/fundacja_logo.png" alt="pwdlogo"></a>
            <ul class="right hide-on-med-and-down">
                <?php wp_nav_menu( array('menu'=>'Fundacja 1 menu main') ); ?> 
            </ul>
        </div>
    </nav>
</div>
<div class="updates_page_content">
    <div class="custom_sub_contaier">
    <?php while ( have_posts() ) : the_post(); ?>
        <div class="content_page contact_page">
            <div class="row">   
                <div class="col s12 m4 l4">
                    <?php the_title( '<h5>', '</h5>' ); ?>
                    <div class="date"><?php echo get_the_date('d.m.Y'); ?></div>  
                    <?php the_content(); ?>
                </div>
                <div class="col s12 m8 l8">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1809.969036069139!2d19.914401604281142!3d50.092226217969966!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47165a48814393b9%3A0x840361b8b52fd018!2sBliska+15%2C+31-331+Krak%C3%B3w!5e0!3m2!1spl!2spl!4v1448196432292" width="700" height="250" frameborder="0" style="border:0" allowfullscreen></iframe>
                </div>
            </div>
            <div role="form" class="wpcf7" id="wpcf7-f123-p124-o1" lang="pl-PL" dir="ltr">
                <div class="screen-reader-response"></div>
                <form action="/kontakt-2/#wpcf7-f123-p124-o1" method="post" class="wpcf7-form" novalidate="novalidate">
                    <div style="display: none;">
                        <input type="hidden" name="_wpcf7" value="123">
                        <input type="hidden" name="_wpcf7_version" value="4.3">
                        <input type="hidden" name="_wpcf7_locale" value="pl_PL">
                        <input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f123-p124-o1">
                        <input type="hidden" name="_wpnonce" value="9c992d921c">
                    </div>
                    <p>
                        <div class="wpcf7-form-control-wrap your-name">
                        <input type="text" name="your-name" placeholder="imię" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false">
                        </div> 
                    </p>
                    <p>
                        <div class="wpcf7-form-control-wrap your-email">
                            <input type="email" name="your-email" value="" placeholder="e-mail" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email" aria-required="true" aria-invalid="false">
                        </div> 
                    </p>
                    <p>
                        <div class="wpcf7-form-control-wrap your-subject">
                            <input type="text" name="your-subject" placeholder="tytuł wiadomości" value="" size="40" class="wpcf7-form-control wpcf7-text" aria-invalid="false">
                        </div> 
                    </p>
                    <p>
                        <div class="wpcf7-form-control-wrap your-message">
                            <textarea name="your-message" placeholder="treść wiadomości" cols="40" rows="30" class="wpcf7-form-control wpcf7-textarea" aria-invalid="false"></textarea>
                        </div> 
                    </p>
                    <p>
                        <input type="submit" value="Wyślij" class="wpcf7-form-control wpcf7-submit">
                    </p>
                    <div class="wpcf7-response-output wpcf7-display-none"></div>
                </form>
            </div>
        </div>  
    <?php endwhile; ?>
    </div>
</div>
<?php get_footer(); ?>
