    <div class="footer">
        <div class="custom_sub_contaier">    
        <div class="row">
            <div class="col s12 m7 l7">
                <p>Szablon został opracowany w ramach projektu <img src="<?php bloginfo('stylesheet_directory'); ?>/img/logo_footer.png" alt="footer_logo"> prowadzonego przez Stowarzyszenie na rzecz  Rozwoju Dolina Gubra i Ministerstwo Administracji i Cyfryzacji www.pwd-online.pl, wersja 1.0</p>
            </div>
            <div class="col s12 m5 l5 footer_logos">
                <img src="<?php bloginfo('stylesheet_directory'); ?>/img/dolina.png" alt="dolina">
                <img src="<?php bloginfo('stylesheet_directory'); ?>/img/godlo.png" alt="maic">
            </div>
        </div>

        </div>        
    </div>
</div>
</body>
</html>