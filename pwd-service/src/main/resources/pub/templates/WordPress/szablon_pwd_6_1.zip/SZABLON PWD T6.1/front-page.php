<?php get_header(); ?>

  	<div class="first_page">

  		<img src="<?php bloginfo('stylesheet_directory'); ?>/img/main_bg.jpg" alt="main_bg" class="bg_img">

  		<div class="navbar-fixed">

    		<nav>

      			<div class="nav-wrapper custom_sub_contaier">

        			<a href="/" class="brand-logo"><img src="<?php bloginfo('stylesheet_directory'); ?>/img/fundacja_logo.png" alt="pwdlogo"></a>

        			<ul class="right hide-on-med-and-down">

                        <?php wp_nav_menu( array('menu'=>'Fundacja 1 menu main') ); ?> 

        		      </ul>

      			</div>

    		</nav>

  		</div>

  		<div class="custom_sub_contaier">

  			<div class="slogan">Wspieramy potrzebujących</div>

      		<p class="slogan_min">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Odio iste deleniti nesciunt unde, corrupti officia corporis, at vitae odit enim expedita quibusdam tempora eligendi. Ducimus asperiores ipsum numquam, quis sequi!</p>

      		<a href="" class="see_projects">Zobacz nasze projekty</a>

      		<a href="" class="about_us_a">O nas</a>

  		</div>

  	</div>

    <div class="main_page_posts">

        <div class="custom_sub_contaier">

            <div class="row">

            <?php

                $latest_blog_posts = new WP_Query( array( 'posts_per_page' => 4 ) );

                if ( $latest_blog_posts->have_posts() ) : 

                    while ( $latest_blog_posts->have_posts() ) : $latest_blog_posts->the_post();

                    ?>

                    <div class="col s12 m3 l3 main_post_col">

                        <div class="image_holder">

                        <?php

                            if ( has_post_thumbnail() ) { the_post_thumbnail(); } else { echo '<div style="width:100%; height:200px; border:1px solid black;"></div>'; }

                        ?> 

                        </div>

                        <h5><?php the_title(); ?></h5>

                        <div class="date"><?php echo get_the_date('d.m.Y'); ?></div>  

                        <p><?php $content = get_the_content(); echo mb_strimwidth($content, 0, 200, '...');?></p>

                        <a href="<?php the_title( get_permalink()); ?>">Więcej</a>

                    </div>

                    <?php

                    endwhile; 

                endif;

            ?>

            </div>

        </div>

    </div>

    <div class="three_cards_segment">

        <div class="custom_sub_contaier">

            <div class="row">

                <div class="col s12 m4 l4">

                    <div class="card_content">

                        <div class="card_title">

                            <div class="title_text">

                                Lorem ipsum dolor sit amet, consectetur.

                            </div>

                            <div class="title_number">1</div>

                        </div>

                        <p>

                            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Harum aliquam vitae saepe nam ratione cupiditate laudantium, fugiat sit consequuntur distinctio pariatur vero provident. 

                        </p>

                        <img src="<?php bloginfo('stylesheet_directory'); ?>/img/three_cards_img_1.jpg" alt="three_cards_img_1">

                    </div>

                </div>

                <div class="col s12 m4 l4">

                    <div class="card_content">

                        <div class="card_title">

                            <div class="title_text">

                                Lorem ipsum dolor sit amet, consectetur.

                            </div>

                            <div class="title_number">2</div>

                        </div>

                        <p>

                            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Harum aliquam vitae saepe nam ratione cupiditate laudantium, fugiat sit consequuntur distinctio pariatur vero provident. 

                        </p>

                        <img src="<?php bloginfo('stylesheet_directory'); ?>/img/three_cards_img_2.jpg" alt="three_cards_img_2">

                    </div>                    

                </div> 

                <div class="col s12 m4 l4">

                    <div class="card_content">

                        <div class="card_title">

                            <div class="title_text">

                                Lorem ipsum dolor sit amet, consectetur.

                            </div>

                            <div class="title_number">3</div>

                        </div>

                        <p>

                            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Harum aliquam vitae saepe nam ratione cupiditate laudantium, fugiat sit consequuntur distinctio pariatur vero provident. 

                        </p>

                        <img src="<?php bloginfo('stylesheet_directory'); ?>/img/three_cards_img_3.jpg" alt="three_cards_img_3">

                    </div>                    

                </div>

            </div>

        </div>

    </div>

    <div class="main_page_text">

        <div class="custom_sub_contaier">

            <h5>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</h5>

            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Explicabo corporis voluptas laboriosam dicta delectus asperiores sed minima distinctio, accusantium ab velit modi eligendi, cum hic laudantium debitis earum. Eum error vel corrupti provident quaerat maiores tempora, ad placeat obcaecati itaque.</p>

            <p>Quam aut placeat quibusdam reiciendis molestiae fugit. Autem sapiente dolorum sit, dolores veritatis a rerum maiores. Tenetur dignissimos voluptatum officiis vel enim fugit, porro laborum velit. Nisi aut quo error, tempore. Mollitia natus voluptas ipsa, dignissimos reprehenderit animi ducimus ab.</p>

        </div>

    </div>

<?php get_footer(); ?>