</div></div>
<div class="footer" style="margin-bottom:0; font-size: 12px;">
    <div class="custom_container">
      <div class="row" style="padding-top:20px; padding-bottom:20px;">
        <div class="col m10 s10 left-align">Szablon został opracowany w ramach projektu <img class="footer_logo_img_text" src="<?php bloginfo('stylesheet_directory'); ?>/img/logo_ft.png"  alt=""> prowadzonego przez Stowarzyszenie na rzecz Rozwoju Dolina Gubra i Ministerstwo Administracji i Cyfryzacji. <a target="_blank" href="http://pwd.dolinagubra.pl/">pwd.dolinagubra.pl</a></div>
        <div class="col m2 s2 right-align"><a href="http://wordpress.internet.pl/?p=100">Polityka cookies</a></div>
      </div>
    </div>
  </div>
</div>
</body>
</html>