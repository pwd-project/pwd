<div class="row">
    <div class="col s12 m6 l6 left-align no_left_padding">
        Data publikacji: <?php echo get_the_date(); ?>
    </div>
    <div class="col s12 m6 l6 right-align no_right_padding">
        Autor: <?php echo get_the_author(); ?>
    </div>
</div>