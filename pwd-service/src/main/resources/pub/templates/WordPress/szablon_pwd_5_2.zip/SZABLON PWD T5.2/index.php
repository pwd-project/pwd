<?php get_header(); ?>
  				<div class="row no_m_b">
  					<div class="col s12 m12 l12 no_p_r">
  						<div class="right_col_content">
  						<div class="bread_crumps" style="font-size:12px !important;">Jesteś tutaj: <a href="/">Bip</a> -> <a href="/">Strona główna</a></div>
  						<div class="main_content_box">
                                        

  							<p class="right-align print_pdf">PDF&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Drukuj</p>
  							<?php get_template_part( 'content', 'page' ); ?>
  							

  						</div>
  					</div>
  				</div>
  			</div>
<?php get_footer(); ?>