</div></div>
<div class="footer" style="margin-bottom:0; font-size: 12px;">
    <div class="custom_container">
      <div class="row" style="padding-top:20px; padding-bottom:20px;">
        <div class="col m10 s10 left-align">Strona została opracowana w ramach projektu PWD online realizowanego przez Stowarzyszenie Na Rzecz Rozwoju Regionu Dolina Gubra przy wsparciu Ministerstwa Administracji i Cyfryzacji</div>
        <div class="col m2 s2 right-align">
			    <img src="<?php bloginfo('stylesheet_directory'); ?>/img/godlo.png" class="right" alt="maic">
                <img src="<?php bloginfo('stylesheet_directory'); ?>/img/dolina.png" class="right" alt="dolina">
        </div>
      </div>
    </div>
  </div>
</div>
</body>
</html>