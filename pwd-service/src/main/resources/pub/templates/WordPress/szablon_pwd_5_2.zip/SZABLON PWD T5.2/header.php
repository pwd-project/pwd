<!DOCTYPE html>



<html>



<head>



    <title><?php wp_title(); ?></title>



    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>



    <meta charset="utf-8">



    <link rel="stylesheet" href="<?php bloginfo('stylesheet_directory'); echo '/css/style.css?' . filemtime( get_stylesheet_directory() . '/css/style.css'); ?>" type="text/css" media="screen, projection" />



    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">



    <link href='https://fonts.googleapis.com/css?family=Lato:400,300,300italic,400italic,700italic,700,900,900italic' rel='stylesheet' type='text/css'>



    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">



    <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>



    <script src="<?php bloginfo('stylesheet_directory'); ?>/js/materialize.js"></script>



    <script src="<?php bloginfo('stylesheet_directory'); ?>/js/slider.js"></script>



    <script type="text/javascript" src="<?php bloginfo('stylesheet_directory'); ?>/js/jssor.js"></script>



    <script type="text/javascript" src="<?php bloginfo('stylesheet_directory'); ?>/js/jssor.slider.js"></script>



    <script type="text/javascript" src="<?php bloginfo('stylesheet_directory'); ?>/js/scripts.js?ver=0.<?php echo time(); ?>"></script>



</head>



<body class="default_styling">



    <div class="navbar-fixed top_menu_nav">



        <nav class="top_nav">



            <div class="custom_container"> 



                <div class="nav-wrapper">



                    <a href="#" data-activates="mobile-demo" class="button-collapse black-text"><i class="material-icons">menu</i></a>



                    <ul class="hide-on-med-and-down">



                        <li class="left pwd_logo"><img src="<?php bloginfo('stylesheet_directory'); ?>/img/pwd_logo.png" style="margin-top:10px;" alt="logo"></li>



                        



                    </ul>



                    <ul class="">



                        <li class="right contrast"><span class="con_op_4">A</span></li>



                        <li class="right contrast"><span class="con_op_3">A</span></li>



                        <li class="right contrast"><span class="con_op_2">A</span></li>



                        <li class="right contrast"><span class="con_op_1">A</span></li>



                        <li class="right fontsize higher_size">A<span class="igorny">++</span></li>



                        <li class="right fontsize medium_size">A<span class="igorny">+</span></li>



                        <li class="right fontsize default_size">A</li>



                    </ul>



                    <?php wp_nav_menu( array('menu'=>'Stowarzyszenie menu górne', 'container_class' => 'side-nav', 'container_id' => 'mobile-demo') ); ?> 



                </div>



            </div>



        </nav>



    </div>



    <div class="navbar-fixed custom_container second_nav_row">



            <nav class="custom_container main_menu_row">



                <div class="nav-wrapper">



                    <a href="/" class="brand-logo"><img src="<?php bloginfo('stylesheet_directory'); ?>/img/herb.png" id="herb"/></a>



                    <?php wp_nav_menu( array('menu'=>'Stowarzyszenie menu górne', 'container_class' => 'right hide-on-med-and-down') ); ?> 



                    <?php wp_nav_menu( array('menu'=>'Stowarzyszenie menu górne', 'container_class' => 'side-nav', 'container_id' => 'mobile-demo') ); ?> 



                </div>



            </nav>



        </div>



        <div class="custom_container slider_row slider_get_width hide-on-med-and-down">



            <div class="search_bar">



                <form action="/" method="get">



                    <img src="<?php bloginfo('stylesheet_directory'); ?>/img/search.png" alt="search">



                    <input type="text" placeholder="szukaj w serwisie..." name="s">



                </form>



            </div>



            <div id="slider1_container" class="col_slider_width" style="position: relative; top: 0px; left: 0px; height: 400px;">



                <div u="slides" class="col_slider_width" style="cursor: move; position: absolute; overflow: hidden; left: 0px; top: 0px;  height: 400px;">



                    <div>



                        <img u="image" src="<?php bloginfo('stylesheet_directory'); ?>/img/slider_1.png" />



                        <div u="caption" t="transition_name1" class="col_slider_width slider_caption" style="display:none;">



                            Lorem ipsum dolor sit amet.



                        </div>



                    </div>



                    <div>



                        <img u="image" src="<?php bloginfo('stylesheet_directory'); ?>/img/slider_2.png" />



                        <div u="caption" t="transition_name2" class="col_slider_width slider_caption" style="display:none;">



                            Lorem ipsum dolor sit amet, consectetur adipisicing.



                        </div>



                    </div>



                </div>



            </div>



        </div>



        <div class="custom_container page_content">



            <div class="row">



                <div class="col m3 l3 s12 no_left_padding">



                    <?php wp_nav_menu( array('menu'=>'menu pod banerem','container_class' => 'side_nav_buttons' ,'link_after' => '<i class="fa fa-chevron-right right"></i>') ); ?> 



                    <div class="patron_box">



                        <h5>patroni medialni</h5>



                        <img src="<?php bloginfo('stylesheet_directory'); ?>/img/parnter_2.png">



                        <img src="<?php bloginfo('stylesheet_directory'); ?>/img/partner_1.png">



                    </div>



                </div>



                <div class="col m9 s12 right_col no_right_padding">



