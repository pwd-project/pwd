<?php get_header(); ?>
<div class="index_page_content">    
    <div class="page_baner">    
        <div class="custom_sub_contaier">
        <h4>Na Guber po ciszę i spokój...</h4>
        <h5>Trasa kajakowa</h5>
        <p>Guber to rzeka spokojna i bardzo malownicza. W Sątocznie wpada do niego Sajna. Przepływa koło miejscowości Prosna, Suliki, Prętławki by w Sępopolu połączyć się z Łyną, którą to już dopłynąć można do granicy.</p>
        <a href="">Trasa Kajakowa</a>

        </div>
                <div class="arrow_holder">
        <img src="<?php bloginfo('stylesheet_directory'); ?>/img/baner_tri.png" alt="baner_tri">
        </div>
    </div>
</div>
<div class="main_page_posts">
    <h5>Aktualności</h5>
    <div class="see_more_holder">   
    <a href="" class="see_more">Zobacz wszystkie</a>
    </div>
    <div class="custom_sub_contaier">
        <div class="posts_row row"> 
            <?php
                $latest_blog_posts = new WP_Query( array( 'posts_per_page' => 3 ) );
                if ( $latest_blog_posts->have_posts() ) : 
                    while ( $latest_blog_posts->have_posts() ) : $latest_blog_posts->the_post();
                    ?>
                    <div class="col s12 m4 l4 main_post_col">
                        <div class="image_holder">
                        <?php
                            if ( has_post_thumbnail() ) { the_post_thumbnail(); } else { echo '<div style="width:100%; height:285px; border:1px solid black;"></div>'; }
                        ?> 
                        </div>
                        <h5><?php the_title(); ?></h5> 
                        <p><?php $content = get_the_content(); echo mb_strimwidth($content, 0, 150, '...');?></p>
                        <a href="<?php the_title( get_permalink()); ?>">Więcej</a>
                    </div>
                    <?php
                    endwhile; 
                endif;
            ?>
        </div>   
    </div>
</div>
<div class="bip_segment">   
    <div class="custom_sub_contaier">
        <div class="row">   
        <div class="col l4 m4 s12"><img src="<?php bloginfo('stylesheet_directory'); ?>/img/bip_logo.png"></div>
        <div class="col l4 m4 s12"><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deserunt aspernatur blanditiis optio eaque cumque vitae necessitatibus assumenda repudiandae aut placeat.</p></div>
        <div class="col l4 m4 s12"><img class="right" src="<?php bloginfo('stylesheet_directory'); ?>/img/button_temp.png"></div>
        </div>
    </div>
</div>

<?php get_footer(); ?>