<!DOCTYPE html>
<html>
<head>
    <title><?php wp_title(); ?></title>
	<meta charset="UTF-8">
	<link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,700,300' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Roboto:400,300' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Lato:400,700,300' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="<?php bloginfo('stylesheet_directory'); echo '/css/style.css?' . filemtime( get_stylesheet_directory() . '/css/style.css'); ?>" type="text/css" media="screen, projection" />
    <script src="<?php bloginfo('stylesheet_directory'); ?>/js/jquery-1.11.3.min.js"></script>
	<script src="<?php bloginfo('stylesheet_directory'); ?>/js/cookies.js"></script>
    <script type="text/javascript" src="<?php bloginfo('stylesheet_directory'); ?>/js/scripts.min.js?ver=0.<?php echo time(); ?>"></script>
</head>
<body class="default_colors">
    <div class="custom_container">
	   <div class="navbar-fixed top-nav">
    	   <nav>
      	     <div class="nav-wrapper custom_sub_contaier">
        	<a href="/" class="brand-logo"><img src="<?php bloginfo('stylesheet_directory'); ?>/img/top-nav-pwdlogo.png" alt="pwdlogo"></a>
        	<ul class="right hide-on-med-and-down contrasts">
          		<li id="cont_1" class="still_same">A</li>
          		<li id="cont_2" class="still_same">A</li>
          		<li id="cont_3" class="still_same">A</li>
          		<li id="cont_4" class="still_same">A</li>
        	</ul>        	
        	<ul class="right hide-on-med-and-down font_sizes">
          		<li class="1_size font-basic still_same">A</li>
          		<li class="2_size font-plus still_same">A<span>+</span></li>
          		<li class="3_size font-plus-plus still_same">A<span>++</span></li>
        	</ul>
      	</div>
    	</nav>
  	</div>
    <div class="main_page_top"> 
    <div class="logo_row">
        <img src="<?php bloginfo('stylesheet_directory'); ?>/img/dolina_logo.png" alt="dolina_logo">
    </div>
    <div class="menu_row">
        <?php wp_nav_menu( array('menu'=>'Dolina menu top') ); ?>
    </div>
  </div>