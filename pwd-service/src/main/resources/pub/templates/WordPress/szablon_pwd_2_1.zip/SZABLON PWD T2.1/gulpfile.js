'use strict';

var gulp = require('gulp');
var sass = require('gulp-sass');
var watch = require('gulp-watch');
var uglify = require('gulp-uglify');
var concat = require('gulp-concat');
var es = require('event-stream');
var gutil = require('gulp-util');
var ftp = require('gulp-ftp');

gulp.task('sass', function () {
  gulp.src('./bower_components/Materialize/sass/style.scss')
    .pipe(sass().on('error', sass.logError))
    .pipe(gulp.dest('./css'));
});
 
gulp.task('sass:watch', function () {
  gulp.watch('./bower_components/Materialize/sass/style.scss', ['sass','upload']);
});

gulp.task('compress', function() {
  var custom_js = gulp.src('./js/scripts.js');
  var materi_js = gulp.src('./bower_components/Materialize/dist/js/materialize.js');

  return es.merge(custom_js,materi_js)
  		.pipe(concat('scripts.min.js'))
  		.pipe(uglify())
    	.pipe(gulp.dest('./dist'));
});

gulp.task('compresjs:watch',function () {
	gulp.watch('./js/scripts.js',['compress']);
});

gulp.task('upload', function () {
    return gulp.src('./css/*')
        .pipe(ftp({
            host: 'ftp.internet.pl',
            user: 'interneta-wordpress',
            pass: 'PWD20151qaz',
            remotePath: './wp-content/themes/bip_vol_2_1/css/'

        }))
        // you need to have some kind of stream after gulp-ftp to make sure it's flushed 
        // this can be a gulp plugin, gulp.dest, or any kind of stream 
        // here we use a passthrough stream 
        .pipe(gutil.noop());
});