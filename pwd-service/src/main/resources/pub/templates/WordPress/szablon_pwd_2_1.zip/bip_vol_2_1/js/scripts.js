$(document).ready(function(){
	  $(".button-collapse").sideNav();
});

$(document).ready(function(){
	$('.show_sub_menu').click(function(){
		$('.under_menu').slideUp();
		var menu = $(this).attr('data-menu');
		console.log(menu);
		$('#'+menu).slideDown();
	});
});

function set_serach_bar_middle(){
	var bar_h = $('.row_img_bg').height();
	var input_height = $('.row_img_bg input').height();
	var menu_image_h = $('.menu_image').height();

	//obliczam różnicę
	var margin_to_set = (bar_h-input_height-menu_image_h)/2;

	//odsuwam wyszukiwarkę
	$('.search_input_bar').css('margin-top',margin_to_set);

	//ustawiam dodatkowo wysykość right_col 
	$('.row_img_bg .right_col').height(bar_h);

	
}

function do_on_resize_and_load()
{
	var menu_image_h = $('.menu_image').height();

	$('.menu_fake_widther').height(menu_image_h);

	var left_col_h = $('.main_content_page').height();
	$('.col_left_fake_widther').height(left_col_h);
}



$(document).ready(function(){
	set_serach_bar_middle();
	do_on_resize_and_load();
});

$( window ).resize(function() {
  	do_on_resize_and_load();
});

$(document).ready(function(){
	$('form img').click(function(){
		$('form').submit();
	});
});

$(document).ready(function(){
	var current_con = "def";
	var ca = document.cookie.split(';');
	for(var i=0; i<ca.length; i++) 
	{
        var c_val = ca[i];
        spl_c = c_val.split('=');
        if(spl_c[0] == "contrast")
        {
        	var current_con = spl_c[1];
        }
	}
    
	if(current_con == "def")
    {
    	$("body").removeClass();
    	$("body").addClass("default_styling");
    }

    if(current_con == "1")
    {
    	$("body").removeClass();
    	$("body").addClass("op_1_styling");
    }

    if(current_con == "2")
    {
    	$("body").removeClass();
    	$("body").addClass("op_2_styling");
    }

    if(current_con == "3")
    {
    	$("body").removeClass();
    	$("body").addClass("op_3_styling");
    }

    $('.con_op_1').click(function(){
    	document.cookie="contrast=def";
    	$("body").removeClass();
    	$("body").addClass("default_styling");
    });

    $('.con_op_2').click(function(){
    	document.cookie="contrast=1";
    	$("body").removeClass();
    	$("body").addClass("op_1_styling");
    });

    $('.con_op_3').click(function(){
    	document.cookie="contrast=2";
    	$("body").removeClass();
    	$("body").addClass("op_2_styling");
    });

    $('.con_op_4').click(function(){
    	document.cookie="contrast=3";
    	$("body").removeClass();
    	$("body").addClass("op_3_styling");
    });
});

$(document).ready(function(){

	var plus = 0;
		$('.default_size').click(function() {
			$('p, .section span, h1, h2, h3, h4, h5, h6, .side_menu_left li, .footer .col').removeAttr('style');
			plus=0;
		});
		$('.medium_size').click(function() {
			$('p, .section span, h1, h2, h3, h4, h5, h6, .side_menu_left li, .footer .col').removeAttr('style');
			$('p, .section span, h1, h2, h3, h4, h5, h6, .side_menu_left li, .footer .col').css("font-size", function() {
				plus=plus+1;
				return parseInt($(this).css('font-size')) * 1.5 + 'px';		
			});
		});
		$('.higher_size').click(function() {
			$('p, .section span, h1, h2, h3, h4, h5, h6, .side_menu_left li, .footer .col').removeAttr('style');
			$('p, .section span, h1, h2, h3, h4, h5, h6, .side_menu_left li, .footer .col').css("font-size", function() {
				
				return parseInt($(this).css('font-size')) * 2 + 'px';		
			});
		
		});
});


