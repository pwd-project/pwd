<!-- treść strony -->
<div class="slider_box">
    <img src="<?php bloginfo('stylesheet_directory'); ?>/img/bip_box_logo.png" class="left" style="margin-top: 14px;" alt="bip_box_logo">
    <img src="<?php bloginfo('stylesheet_directory'); ?>/img/rso_box_logo.png" class="right" alt="rso_box_logo">
</div>
<div class="page_container">
	<?php the_title( '<h5>', '</h5>' ); ?>
	<?php the_content(); ?>
</div>
<!-- ./treść strony -->