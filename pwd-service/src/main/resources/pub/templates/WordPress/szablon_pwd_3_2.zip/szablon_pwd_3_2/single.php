<?php get_header(); ?>
<!-- post -->
<div class="page_container">
<?php while ( have_posts() ) : the_post();
	get_template_part( 'content', get_post_format() );
	endwhile;
?>
</div>
<!-- ./post -->
<?php get_footer(); ?>
