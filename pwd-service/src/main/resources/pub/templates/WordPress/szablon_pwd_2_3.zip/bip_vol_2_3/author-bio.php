<div class="row"  style="font-size: 12px !important;">

    <div class="col s12 m6 l6 left-align no_p_l">

        Data publikacji: <?php echo get_the_date(); ?>

    </div>

    <div class="col s12 m6 l6 right-align no_p_r">

        Autor: <?php echo get_the_author(); ?>

    </div>

</div>