<?php

add_theme_support( 'post-thumbnails' ); 