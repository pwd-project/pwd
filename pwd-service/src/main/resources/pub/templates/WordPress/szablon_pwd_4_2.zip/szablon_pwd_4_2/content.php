<?php if ( is_single() ) : ?>
<!-- content -->
<div class="single_post">	

	<?php the_title( '<h5>', '</h5>' ); ?>

	<div class="date"><?php echo get_the_date('d.m.Y'); ?></div>  

	<?php the_content(); ?>

	<?php if ( has_post_thumbnail() ) { the_post_thumbnail(); } else {} ?>

</div>

<?php else: ?>

<div class="update_row row">

    <div class="col s12 m4 l4">

        <?php if ( has_post_thumbnail() ) { the_post_thumbnail(); } else echo '<div style="width:370px; height:300px; border:1px solid black;"></div>'; ?>

    </div>

    <div class="col s12 m8 l8 right_col">

    <?php the_title( sprintf( '<h5>', esc_url( get_permalink() ) ), '</h5>' ); ?>    	

	<div class="date"><?php echo get_the_date('d.m.Y'); ?></div>  

		<?php

			the_content( sprintf(

			__( 'Continue reading %s', 'twentyfifteen' ),

			the_title( '<span class="screen-reader-text">', '</span>', false )

			) );

		 ?>

		 

		 <a href="<?php the_title( get_permalink()); ?>">Czytaj całość</a>

		

    </div>



</div>
<!-- ./content -->
    <div class="main_page_contact">  
        <h5>Stowarzyszenie na Rzecz Rozwoju Regionu<br>Dolina Gubra</h5>
        <p> 
            11-430 Korsze, Studzieniec 27<br>
            <a href="biuro@dolinagubra.pl">biuro@dolinagubra.pl</a><br><br>
            KRS 0000412628 <br>
            REGON 281379846 <br>
            NIP 7422246158<br><br>
            Nr konta:<br><br>
            BGŻ SA O/Kętrzyn 66203000451110000002285110
        </p>
    </div>
<?php endif; ?>