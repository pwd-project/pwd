
<div class="content_page">

<?php the_title( '<h5>', '</h5>' ); ?>

<div class="date"><?php echo get_the_date('d.m.Y'); ?></div>  

<?php the_content(); ?>

</div>	
