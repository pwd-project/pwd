<!DOCTYPE html>
<html>
<head>
  <title><?php wp_title(); ?></title>
  <meta charset="UTF-8">
  <link href='https://fonts.googleapis.com/css?family=Roboto:400,500,300,700' rel='stylesheet' type='text/css'>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="<?php bloginfo('stylesheet_directory'); echo '/css/style.css?' . filemtime( get_stylesheet_directory() . '/css/style.css'); ?>" type="text/css" media="screen, projection" />
  <link rel="stylesheet" href="<?php bloginfo('stylesheet_directory'); ?>/css/jquery.bxslider.css" type="text/css"/>
    <script src="http://code.jquery.com/jquery-1.11.3.min.js"></script>
    <script type="text/javascript" src="<?php bloginfo('stylesheet_directory'); ?>/js/jquery.bxslider.js"></script>
    <script type="text/javascript" src="<?php bloginfo('stylesheet_directory'); ?>/js/cookies.js"></script>
    <script type="text/javascript" src="<?php bloginfo('stylesheet_directory'); ?>/js/scripts.js?ver=0.<?php echo time(); ?>"></script>
</head>
<body class="default_colors">
  <div class="custom_container">
    <div class="navbar-fixed top-nav">
        <nav>
            <div class="nav-wrapper custom_sub_contaier">
              <a href="/" class="brand-logo"><img src="<?php bloginfo('stylesheet_directory'); ?>/img/top-nav-pwdlogo.png" alt="pwdlogo"></a>
              <ul class="right hide-on-med-and-down contrasts">
                  <li id="cont_1" class="still_same">A</li>
                  <li id="cont_2" class="still_same">A</li>
                  <li id="cont_3" class="still_same">A</li>
                  <li id="cont_4" class="still_same">A</li>
              </ul>         
              <ul class="right hide-on-med-and-down font_sizes">
                  <li class="1_size font-basic still_same">A</li>
                  <li class="2_size font-plus still_same">A<span>+</span></li>
                  <li class="3_size font-plus-plus still_same">A<span>++</span></li>
              </ul>
            </div>
        </nav>
      </div>
      <div class="header">
        <div class="custom_sub_contaier">
          <img src="<?php bloginfo('stylesheet_directory'); ?>/img/gmina_logo.png" alt="gmina_logo">
        </div>
      </div>
      <div class="header_menu">
        <div class="custom_sub_contaier">
          <ul class="left">
            <?php wp_nav_menu( array('menu'=>'Gmina 3 top') ); ?> 
          </ul>
          <ul class="right">
            <li><a class="social_ico" href=""><i class="fa fa-facebook"></i></a></li>
            <li><a class="social_ico" href=""><i class="fa fa-twitter"></i></a></li>
            <li><a class="social_ico" href=""><i class="fa fa-instagram"></i></a></li>
          </ul>
          <form action="/" method="get">
          <input type="text" placeholder="szukaj"  name="s">
          </form>
        </div>
      </div>
      <div class="page_content">
        <div class="custom_sub_contaier">
      <div class="custom_left_col">
        <div class="left_menu">
          <ul>
          <?php wp_nav_menu( array('menu'=>'Gmina 3 lewe') ); ?> 
          </ul>
        </div>
        <img src="<?php bloginfo('stylesheet_directory'); ?>/img/partnerzy.jpg" alt="partnerzy" class="partnerzy">
      </div>
      <div class="custom_right_col">
