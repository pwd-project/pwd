<?php
if ( is_single() ) :
?>
<div class="single_post">	

<?php if ( has_post_thumbnail() ) { the_post_thumbnail(); } else {} ?>
<?php the_title( '<h5>', '</h5>' ); ?>
<div class="date"><?php echo get_the_date('d.m.Y'); ?></div>  
<?php the_content(); ?>
</div>
<?php else: ?>
<div class="update_row row">
    <div class="col s12 m4 l4">
        <?php if ( has_post_thumbnail() ) { the_post_thumbnail(); } else echo '<div style="width:370px; height:300px; border:1px solid black;"></div>'; ?>
    </div>
    <div class="col s12 m8 l8 right_col">
    <?php the_title( sprintf( '<h5>', esc_url( get_permalink() ) ), '</h5>' ); ?>    	
	<div class="date"><?php echo get_the_date('d.m.Y'); ?></div>  
		<?php
			the_content( sprintf(
			__( 'Continue reading %s', 'twentyfifteen' ),
			the_title( '<span class="screen-reader-text">', '</span>', false )
			) );
		 ?>
		 
		 <a href="<?php the_title( get_permalink()); ?>">Czytaj całość</a>
		
    </div>

</div>
<?php endif; ?>