<?php get_header(); ?>
  	<div class="first_page">
  		<img src="<?php bloginfo('stylesheet_directory'); ?>/img/main_bg.png" alt="main_bg" class="bg_img">
  			<div class="navbar-fixed">
    			<nav>
      				<div class="nav-wrapper custom_sub_contaier">
        				<a href="/" class="brand-logo"><img src="<?php bloginfo('stylesheet_directory'); ?>/img/fundacja_logo.png" alt="pwdlogo"></a>
        				<ul class="right hide-on-med-and-down">
                  <?php wp_nav_menu( array('menu'=>'Fundacja 1 menu main') ); ?> 
        				</ul>
      				</div>
    			</nav>
  			</div>
  			<div class="custom_sub_contaier">
  			<div class="slogan">Wspieramy potrzebujących</div>
  			<p class="slogan_min">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Odio iste deleniti nesciunt unde, corrupti officia corporis, at vitae odit enim expedita quibusdam tempora eligendi. Ducimus asperiores ipsum numquam, quis sequi!</p>
  			<a href="" class="see_projects">Zobacz nasze projekty</a>
  			<a href="" class="about_us_a">O nas</a>
  			</div>
  	</div>
  	<div class="second_page">
  		<div class="page_title">Twoja strona pod naszym nadzorem</div>
  		<div class="page_subtitle">Zobacz jak wygląda nasz proces analizy</div>
  		<div class="row images_row custom_sub_contaier">
  			<div class="col l4 m4 s12">
                <div class="image_holder">
  				  <img src="<?php bloginfo('stylesheet_directory'); ?>/img/page_2_img_1.png" alt="page_2_img_1">
                </div>
  				<h5>Odwiedziny Twojej strony</h5>
  				<h6>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nostrum eum accusantium odio corrupti dolores dolor.</h6>
  			</div>
  			<div class="col l4 m4 s12">
                <div class="image_holder">
  				  <img src="<?php bloginfo('stylesheet_directory'); ?>/img/page_2_img_2.png" alt="page_2_img_1">
                </div>
  				<h5>Analiza danych</h5>
  				<h6>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nostrum eum accusantium odio corrupti dolores dolor.</h6>  				
  			</div>
  			<div class="col l4 m4 s12">
  				<img src="<?php bloginfo('stylesheet_directory'); ?>/img/page_2_img_3.png" alt="page_2_img_1">
  				<h5>Raport</h5>
  				<h6>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nostrum eum accusantium odio corrupti dolores dolor.</h6>	
  			</div>
  		</div>
  	</div>
    <div class="third_page">
        <div class="page_title">Do pobrania</div>
        <div class="page_subtitle">Bezpłatne szablony stron www z certyfikatem PWD</div>
        <div class="custom_sub_contaier">
            <div class="row download_cards_row">
                <div class="col l4 m4 s12">
                <div class="download_card">
                    <img src="<?php bloginfo('stylesheet_directory'); ?>/img/page_3_img.png" alt="">
                    <h5>PWD TPL.CLASSIC.01</h5>
                    <h6>Pobierz werjsę dla:</h6>
                    <div class="row logo_row">
                        <div class="col s4"><img src="<?php bloginfo('stylesheet_directory'); ?>/img/wordpress_logo.png" alt="wordpress_logo"></div>
                        <div class="col s4"><img src="<?php bloginfo('stylesheet_directory'); ?>/img/drupal_logo.png" alt="drupal_logo"></div>
                        <div class="col s4"><img src="<?php bloginfo('stylesheet_directory'); ?>/img/joomla_logo.png" alt="joomla_logo"></div>
                    </div>
                </div>
                </div>
                <div class="col l4 m4 s12">
                    <div class="download_card">
                    <img src="<?php bloginfo('stylesheet_directory'); ?>/img/page_3_img.png" alt="">
                    <h5>PWD TPL.CLASSIC.01</h5>
                    <h6>Pobierz werjsę dla:</h6>
                    <div class="row logo_row">
                        <div class="col s4"><img src="<?php bloginfo('stylesheet_directory'); ?>/img/wordpress_logo.png" alt="wordpress_logo"></div>
                        <div class="col s4"><img src="<?php bloginfo('stylesheet_directory'); ?>/img/drupal_logo.png" alt="drupal_logo"></div>
                        <div class="col s4"><img src="<?php bloginfo('stylesheet_directory'); ?>/img/joomla_logo.png" alt="joomla_logo"></div>
                    </div>                    
                    </div>
                </div>
                <div class="col l4 m4 s12">
                    <div class="download_card">
                    <img src="<?php bloginfo('stylesheet_directory'); ?>/img/page_3_img.png" alt="">
                    <h5>PWD TPL.CLASSIC.01</h5>
                    <h6>Pobierz werjsę dla:</h6>
                    <div class="row logo_row">
                        <div class="col s4"><img src="<?php bloginfo('stylesheet_directory'); ?>/img/wordpress_logo.png" alt="wordpress_logo"></div>
                        <div class="col s4"><img src="<?php bloginfo('stylesheet_directory'); ?>/img/drupal_logo.png" alt="drupal_logo"></div>
                        <div class="col s4"><img src="<?php bloginfo('stylesheet_directory'); ?>/img/joomla_logo.png" alt="joomla_logo"></div>
                    </div>                    
                    </div>
                </div>
            </div>
            <div class="row more_themes"><a href="#">więcej szablonów</a></div>
        </div>
    </div>
    <div class="fourth_page">
        <div class="page_title">Globalny wskaźnik dostępności</div>
        <div class="page_subtitle">pwd rank</div>   
        <img src="<?php bloginfo('stylesheet_directory'); ?>/img/page_4_img.png" alt="page_4_img">     
    </div>
    <div class="fifth_page">
        <div class="page_title">Ranking pwd top100</div>
        <div class="page_subtitle">najbardziej dostępne strony użyteczności publicznej</div>     
        <div class="custom_sub_contaier">    
        <table>
            <tr class="head_row">
                <th align="center"><img src="<?php bloginfo('stylesheet_directory'); ?>/img/page_5_img.png" alt="page_5_img"></th>
                <th>pkt.</th>
                <th>kategoria</th>
                <th>nazwa</th>
                <th>url</th>
                <th>działania</th>
            </tr>
            <tr class="hidden_tr">
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
            </tr>            
            <tr>
                <td>1</td>
                <td>100/100</td>
                <td>Administracja</td>
                <td>System Ministerstwa Obrony Narodowej</td>
                <td><a href="#">www.mon.gov.pl</a></td>
                <td>
                    <img src="<?php bloginfo('stylesheet_directory'); ?>/img/page_5_img_2.png" alt="page_5_img_2">
                    <img src="<?php bloginfo('stylesheet_directory'); ?>/img/page_5_img_3.png" alt="page_5_img_3">
                </td>
            </tr>
            <tr>
                <td>1</td>
                <td>100/100</td>
                <td>Administracja</td>
                <td>System Ministerstwa Obrony Narodowej</td>
                <td><a href="#">www.mon.gov.pl</a></td>
                <td>
                    <img src="<?php bloginfo('stylesheet_directory'); ?>/img/page_5_img_2.png" alt="page_5_img_2">
                    <img src="<?php bloginfo('stylesheet_directory'); ?>/img/page_5_img_3.png" alt="page_5_img_3">
                </td>
            </tr>
            <tr>
                <td>2</td>
                <td>100/100</td>
                <td>Administracja</td>
                <td>System Ministerstwa Obrony Narodowej</td>
                <td><a href="#">www.mon.gov.pl</a></td>
                <td>
                    <img src="<?php bloginfo('stylesheet_directory'); ?>/img/page_5_img_2.png" alt="page_5_img_2">
                    <img src="<?php bloginfo('stylesheet_directory'); ?>/img/page_5_img_3.png" alt="page_5_img_3">
                </td>
            </tr>
            <tr>
                <td>3</td>
                <td>100/100</td>
                <td>Administracja</td>
                <td>System Ministerstwa Obrony Narodowej</td>
                <td><a href="#">www.mon.gov.pl</a></td>
                <td>
                    <img src="<?php bloginfo('stylesheet_directory'); ?>/img/page_5_img_2.png" alt="page_5_img_2">
                    <img src="<?php bloginfo('stylesheet_directory'); ?>/img/page_5_img_3.png" alt="page_5_img_3">
                </td>
            </tr>
            <tr>
                <td>4</td>
                <td>100/100</td>
                <td>Administracja</td>
                <td>System Ministerstwa Obrony Narodowej</td>
                <td><a href="#">www.mon.gov.pl</a></td>
                <td>
                    <img src="<?php bloginfo('stylesheet_directory'); ?>/img/page_5_img_2.png" alt="page_5_img_2">
                    <img src="<?php bloginfo('stylesheet_directory'); ?>/img/page_5_img_3.png" alt="page_5_img_3">
                </td>
            </tr>    
            <tr>
                <td>5</td>
                <td>100/100</td>
                <td>Administracja</td>
                <td>System Ministerstwa Obrony Narodowej</td>
                <td><a href="#">www.mon.gov.pl</a></td>
                <td>
                    <img src="<?php bloginfo('stylesheet_directory'); ?>/img/page_5_img_2.png" alt="page_5_img_2">
                    <img src="<?php bloginfo('stylesheet_directory'); ?>/img/page_5_img_3.png" alt="page_5_img_3">
                </td>
            </tr>                                                        
        </table>  
        </div>
        <div class="row more_themes"><a href="#">zobacz pełny ranking</a></div>
    </div>

<?php get_footer(); ?>