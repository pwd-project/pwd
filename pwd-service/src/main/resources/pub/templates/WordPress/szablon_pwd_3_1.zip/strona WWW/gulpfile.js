'use strict';

var gulp    = require('gulp');
var sass    = require('gulp-sass');
var watch   = require('gulp-watch');
var uglify  = require('gulp-uglify');
var concat  = require('gulp-concat');
var es      = require('event-stream');
var gutil   = require('gulp-util');
var ftp     = require('gulp-ftp');
var runSequence = require('run-sequence');

gulp.task('sass', function () {
  gulp.src('./dev/style.scss')
    .pipe(sass().on('error', sass.logError))
    .pipe(gulp.dest('./css'));
});
 
gulp.task('sass:watch', function () {
  gulp.watch('./dev/style.scss', ['sass_and_upload']);
});

gulp.task('compress', function() {
  var custom_js = gulp.src('./dev/scripts.js');
  var materi_js = gulp.src('./node_modules/materialize-css/dist/js/materialize.js');

  return es.merge(custom_js,materi_js)
  		.pipe(concat('scripts.min.js'))
  		.pipe(uglify())
    	.pipe(gulp.dest('./js'));
});

gulp.task('compresjs:watch',function () {
	gulp.watch('./dev/scripts.js',['compress']);
});

gulp.task('upload', function () {
    return gulp.src('./css/*')
        .pipe(ftp({
            host: 'ftp.internet.pl',
            user: 'interneta-wordpress',
            pass: 'PWD20151qaz',
            remotePath: './wp-content/themes/fundacja_1_wp/css/'

        }))
        // you need to have some kind of stream after gulp-ftp to make sure it's flushed 
        // this can be a gulp plugin, gulp.dest, or any kind of stream 
        // here we use a passthrough stream 
        .pipe(gutil.noop());
});

gulp.task('sass_and_upload', function(callback) {
  runSequence('sass','upload', callback);
});