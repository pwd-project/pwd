<?php
get_header(); ?>
<!-- wylistowane -->
<div class="slider_box">
    <img src="<?php bloginfo('stylesheet_directory'); ?>/img/bip_box_logo.png" class="left" style="margin-top: 14px;" alt="bip_box_logo">
    <img src="<?php bloginfo('stylesheet_directory'); ?>/img/rso_box_logo.png" class="right" alt="rso_box_logo">
</div>
<div class="main_updates">
	<?php if ( have_posts() ) : ?>
	
			<?php
			// Start the Loop.
			while ( have_posts() ) : the_post();

				get_template_part( 'content', 'search' );

			// End the loop.
			endwhile;

		endif;
		?>

 </div>
<!-- ./wylistowane -->
<?php get_footer(); ?>
