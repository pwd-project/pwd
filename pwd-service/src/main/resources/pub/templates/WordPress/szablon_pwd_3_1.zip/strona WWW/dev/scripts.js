$(document).ready(function(){
	var img_bg_h = $('.bg_img').height();
	$('.first_page').css('min-height',img_bg_h-50);
});

$(document).ready(function(){
		var plus = 0;
		$('.font-basic').click(function() {
			$('p, span, h1, h2, h3, h4, h5:not(".rank-value"), h6,  li:not(".still_same"), td, th').removeAttr('style');
			plus=0;
		});
		$('.font-plus').click(function() {
			$('p, span, h1, h2, h3, h4, h5:not(".rank-value"), h6,  li:not(".still_same"), td, th').removeAttr('style');
			$('p, .section span, h1, h2, h3, h4, h5:not(".rank-value"), h6,  li:not(".still_same"), td, th').css("font-size", function() {
				plus=plus+1;
				return parseInt($(this).css('font-size')) * 1.5 + 'px';		
			});
		});
		$('.font-plus-plus').click(function() {
			$('p,  span, h1, h2, h3, h4, h5:not(".rank-value"), h6,  li:not(".still_same"), td, th').removeAttr('style');
			$('p, .section span, h1, h2, h3, h4, h5:not(".rank-value"), h6,  li:not(".still_same"), td, th').css("font-size", function() {
				
				return parseInt($(this).css('font-size')) * 2 + 'px';		
			});
		
		});
});

$(document).ready(function(){
	$('#cont_1').click(function() {
		$('body').removeClass();
		$('body').addClass('default_colors');
			Cookies.set('style', '1');
		});
		$('#cont_2').click(function() {
			$('body').removeClass();
			$('body').addClass('contrast_2_colors');
				Cookies.set('style', '2');
		});
		$('#cont_3').click(function() {
			$('body').removeClass();
			$('body').addClass('contrast_3_colors');
				Cookies.set('style', '3');
		});
		$('#cont_4').click(function() {
			$('body').removeClass();
			$('body').addClass('contrast_4_colors');
				Cookies.set('style', '4');
		});
		
		var style = Cookies.get('style');
		if(style == 1){
		$('body').removeClass();
		$('body').addClass('default_colors');
		}
		else if(style == 2){
			$('body').removeClass();
			$('body').addClass('contrast_2_colors');
		}
		else if(style == 3){
			$('body').removeClass();
			$('body').addClass('contrast_3_colors');
		}
		else if(style == 4){
			$('body').removeClass();
			$('body').addClass('contrast_4_colors');
		}
});

