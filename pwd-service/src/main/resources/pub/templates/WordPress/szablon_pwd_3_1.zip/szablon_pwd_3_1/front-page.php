<?php get_header(); ?>
<!-- strona główna -->
    <div class="slider_imgs">
        <ul class="bxslider">
            <li><img src="<?php bloginfo('stylesheet_directory'); ?>/img/slider_img.jpg" title="Funky roots"/></li>
            <li><img src="<?php bloginfo('stylesheet_directory'); ?>/img/slider_img.jpg" title="Funky roots"/></li>
            <li><img src="<?php bloginfo('stylesheet_directory'); ?>/img/slider_img.jpg" title="Funky roots"/></li>
            <li><img src="<?php bloginfo('stylesheet_directory'); ?>/img/slider_img.jpg" title="Funky roots"/></li>
        </ul>
    </div>
    <div class="slider_box">
        <img src="<?php bloginfo('stylesheet_directory'); ?>/img/bip_box_logo.png" class="left" style="margin-top: 14px;" alt="bip_box_logo">
        <img src="<?php bloginfo('stylesheet_directory'); ?>/img/rso_box_logo.png" class="right" alt="rso_box_logo">
    </div>

    <div class="main_updates">
    <?php
        $latest_blog_posts = new WP_Query( array( 'posts_per_page' => 4 ) );
        if ( $latest_blog_posts->have_posts() ) : 
        while ( $latest_blog_posts->have_posts() ) : $latest_blog_posts->the_post();
        ?>
        <div class="update">
            <?php if ( has_post_thumbnail() ) { the_post_thumbnail(); } else { echo '<div style="width:170px; height:115px; border:1px solid black; float:left; margin-right: 50px;"></div>'; } ?>
            <h5><?php the_title(); ?></h5><br>
            <div class="date"><?php echo get_the_date('d.m.Y'); ?></div>
            <p><?php $content = get_the_content(); echo mb_strimwidth($content, 0, 200, '...');?> <a href="<?php the_title( get_permalink()); ?>">czytaj więcej</a></p>
        </div>
        <?php endwhile; endif; ?>                           
    </div>
<!-- ./strona główna -->    
<?php get_footer(); ?>