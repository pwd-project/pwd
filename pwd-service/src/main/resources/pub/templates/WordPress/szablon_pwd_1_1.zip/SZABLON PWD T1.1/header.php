<!DOCTYPE html>

<html>

<head>

	<title>BIP</title>

	<meta charset="utf-8" /> 

    <title><?php wp_title(); ?></title>

	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>

	<!--<link rel="stylesheet" href="<?php bloginfo('stylesheet_directory'); ?>/css/style.css">-->

	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

    <link href='https://fonts.googleapis.com/css?family=Lato:400,700' rel='stylesheet' type='text/css'>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">

    <link rel="stylesheet" href="<?php bloginfo('stylesheet_directory'); echo '/css/style.css?' . filemtime( get_stylesheet_directory() . '/css/style.css'); ?>" type="text/css" media="screen, projection" />

	<script type="text/javascript" src="<?php bloginfo('stylesheet_directory'); ?>/js/materialize.min.js"></script>

	<script type="text/javascript" src="<?php bloginfo('stylesheet_directory'); ?>/js/scripts.js?ver=0.<?php echo time(); ?>"></script>

</head>

<body class="default_styling">

	<div class="navbar-fixed">

    	<nav class="top_nav">

            <div class="custom_container"> 

          		<div class="nav-wrapper">

            		<a href="#" data-activates="mobile-demo" class="button-collapse black-text"><i class="material-icons">menu</i></a>

            		<ul class="hide-on-med-and-down">

            			<li class="left pwd_logo"><img src="<?php bloginfo('stylesheet_directory'); ?>/img/pwd_logo.png" alt="logo"></li>

              		    

            		</ul>

                    <ul class="">

                        <li class="right contrast"><span class="con_op_4">A</span></li>

                        <li class="right contrast"><span class="con_op_3">A</span></li>

                        <li class="right contrast"><span class="con_op_2">A</span></li>

                        <li class="right contrast"><span class="con_op_1">A</span></li>

                        <li class="right fontsize higher_size">A<span class="igorny">++</span></li>

                        <li class="right fontsize medium_size">A<span class="igorny">+</span></li>

                        <li class="right fontsize default_size">A</li>

                    </ul>

            		<ul class="side-nav black-text" id="mobile-demo">

                        <li><img src="<?php bloginfo('stylesheet_directory'); ?>/img/pwd_logo.png" alt="logo"></li>

                        <?php wp_nav_menu( array('menu'=>'menu pod banerem') ); ?> 

          			</ul>

          		</div>

            </div>

    	</nav>

  	</div>

  	<div class="custom_container">

        <div class="row no_m_b main_content_page">

  		    <div class="col m12 l3 s12 white main_left_col">

  		    	<div class="lef_col_faker_width"></div>

  			    <div class="row bip_main_logo">

  				   <a href="/"> <img src="<?php bloginfo('stylesheet_directory'); ?>/img/logo_bip.png" alt="" class="center-image" style=" margin-left:0.75rem;   max-width: 80%;"></a>

  			    </div>

  			    <div class="row">

  			    	<div class="col s12 m12 l12">

              <div style="width:100%; display:block; line-height:2rem;">

                <form action="/" method="get">

  						<input class="search-input" placeholder="szukaj w Bip..." type="text" name="s">

  						<!--<i class="fa fa-search fa-3"></i>-->

              <div style="width:25%; display: inline-block;">

                <img src="<?php bloginfo('stylesheet_directory'); ?>/img/search.png" alt="search" style="max-width:100%; display:block; float:left; margin-left:10px; margin-top: 7px;">

                </form>



              </div>

              </div>

  			  

            		</div>

  				</div>

  				<div class="row side_menu_left">

  					<div class="col m12 s12 l12">

  						<h5 class="text-uppercase"><strong>Informacje</strong></h5>

                        <?php wp_nav_menu( array('menu'=>'menu lewe 1') ); ?> 

  					</div>

  				</div>

  				<div class="row side_menu_left">

  					<div class="col m12 s12 l12">

  						<h5 class="text-uppercase"><strong>Zamówienia publiczne:</strong></h5>

  						<ul>

                            <?php wp_nav_menu( array('menu'=>'menu lewe 2') ); ?> 

  						</ul>

  					</div>

  				</div>

  				<div class="row side_menu_left">

  					<div class="col m12 s12 l12">

  						<h5 class="text-uppercase"><strong>Stowarzyszenie Paris</strong></h5>

  						<p>ul. Ulicowa 23</p>

  						<p>02-222 Warszawa</p>

  						<p>tel.: +48 22 333 333 333</p>

  						<p>fax: +48 444 444 444</p>

  						<p><a href="" target="_blank">info@paris.gov.pl</a></p>

  						<br>

  						<p>KRS: 22332142344</p>

  						<p>NIP: 884 222 22 22</p>

  					</div>

  				</div>

  			</div>

        	<div class="col m12 l9 s12 no_p_l no_p_r">

          		<div class="row no_m_b">

            		<div class="col s12 m12 l12 no_p_l no_p_r">

  						<div class="image_holder">

  							<img src="<?php bloginfo('stylesheet_directory'); ?>/img/baner.jpg" alt="baner">

  							<div class="menu_image">

	  							<ul class="text-uppercase">

		  							<?php wp_nav_menu( array('menu'=>'menu pod banerem') ); ?> 

	  							</ul>

  							</div>

  						</div>

  					</div>

  				</div>