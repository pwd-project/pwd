        </div>
  	</div>
</div>
<div class="footer">
    <div class="custom_container">
        <div style="color:#333333;" class="">
          	<div class="row no_m_b">
            	<div class="col m6 l6 s12">
              		Szablon został opracowany w ramach projektu <img class="footer_logo_img_text" src="<?php bloginfo('stylesheet_directory'); ?>/img/logo_ft.png"  alt=""> prowadzonego przez Stowarzyszenie na rzecz Rozwoju Dolina Gubra i Ministerstwo Administracji i Cyfryzacji <a href="http://pwd.dolinagubra.pl/" target="_blank">pwd.dolinagubra.pl</a>
            	</div>
            	<div class="col m6 l6 s12">
              		<img src="<?php bloginfo('stylesheet_directory'); ?>/img/gubra.png" class="right" alt="gubra">
              		<img src="<?php bloginfo('stylesheet_directory'); ?>/img/maic.png" class="right" alt="maic">
            	</div>
          	</div>
        </div>
      </div>
    </div>
</body>
</html>