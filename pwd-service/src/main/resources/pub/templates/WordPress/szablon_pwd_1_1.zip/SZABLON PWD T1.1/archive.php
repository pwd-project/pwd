<?php
get_header(); ?>

<div class="row no_m_b">
  	<div class="col s12 m12 l12 no_p_r">
  		<div class="right_col_content">
  			<div class="bread_crumps" style="font-size:12px !important;">Jesteś tutaj: <a href="/">Bip</a> -> <a href="<?php echo $_SERVER['REQUEST_URI']; ?>"><?php the_archive_title(); ?></a></div>
  			<div class="main_content_box">

		<?php if ( have_posts() ) : ?>

			<header class="page-header">
				<?php
					the_archive_title( '<h5>', '</h5>' );
					the_archive_description( '<div class="taxonomy-description">', '</div>' );
				?>
			</header><!-- .page-header -->

			<?php
			// Start the Loop.
			while ( have_posts() ) : the_post();

				/*
				 * Include the Post-Format-specific template for the content.
				 * If you want to override this in a child theme, then include a file
				 * called content-___.php (where ___ is the Post Format name) and that will be used instead.
				 */
				get_template_part( 'content', 'search' );

			// End the loop.
			endwhile;

			// Previous/next page navigation.
			the_posts_pagination( array(
				'prev_text'          => __( 'Previous page', 'twentyfifteen' ),
				'next_text'          => __( 'Next page', 'twentyfifteen' ),
				'before_page_number' => '<span class="meta-nav screen-reader-text">' . __( 'Page', 'twentyfifteen' ) . ' </span>',
			) );

		// If no content, include the "No posts found" template.
		else :
			get_template_part( 'content', 'none' );

		endif;
		?>

  						</div>
  					</div>
  				</div>
  			</div>

<?php get_footer(); ?>
