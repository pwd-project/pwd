<!-- rekord listowania -->
        <div class="update">
            <?php if ( has_post_thumbnail() ) { the_post_thumbnail(); } else { echo '<div style="width:170px; height:115px; border:1px solid black; float:left; margin-right: 50px;"></div>'; } ?>
            <h5><?php the_title(); ?></h5><br>
            <div class="date"><?php echo get_the_date('d.m.Y'); ?></div>
            <p><?php $content = get_the_content(); echo mb_strimwidth($content, 0, 200, '...');?> <a href="<?php the_title( get_permalink()); ?>">czytaj więcej</a></p>
        </div>
<!-- ./rekord listowania -->


