<?php get_header(); ?>
<div class="slider_box">
    <img src="<?php bloginfo('stylesheet_directory'); ?>/img/bip_box_logo.png" class="left" style="margin-top: 14px;" alt="bip_box_logo">
    <img src="<?php bloginfo('stylesheet_directory'); ?>/img/rso_box_logo.png" class="right" alt="rso_box_logo">
</div>
<?php while ( have_posts() ) : the_post(); ?>

				





					<div class="entry-content">

						<div class="entry-attachment">
							<?php
								/**
								 * Filter the default Twenty Fifteen image attachment size.
								 *
								 * @since Twenty Fifteen 1.0
								 *
								 * @param string $image_size Image size. Default 'large'.
								 */
								$image_size = apply_filters( 'twentyfifteen_attachment_size', 'large' );

								echo wp_get_attachment_image( get_the_ID(), $image_size );
							?>

							<?php if ( has_excerpt() ) : ?>
								<div class="entry-caption">
									<?php the_excerpt(); ?>
								</div><!-- .entry-caption -->
							<?php endif; ?>

						</div><!-- .entry-attachment -->


					</div><!-- .entry-content -->



			

				<?php



				// End the loop.
				endwhile;
			?>

<?php get_footer(); ?>
