<?php get_header(); ?>
<div class="main_updates">
	<?php if ( have_posts() ) : ?>
	<h5 class="search_header"><?php printf( __( 'Wyniki wyszukiwania dla: %s', 'twentyfifteen' ), get_search_query() ); ?></h5>
	<?php while ( have_posts() ) : the_post(); ?>
	<?php get_template_part( 'content', 'search' ); endwhile; endif; ?>
</div>
<?php get_footer(); ?>
