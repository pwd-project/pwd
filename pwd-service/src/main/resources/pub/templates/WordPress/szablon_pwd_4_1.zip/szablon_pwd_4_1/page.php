<?php get_header(); ?>
<div class="index_page_content category_banner">    
    <div class="page_baner">    
        <div class="custom_sub_contaier">
            <h5><?php the_title(); ?></h5>
        </div>
        <div class="arrow_holder">
            <img src="<?php bloginfo('stylesheet_directory'); ?>/img/baner_tri.png" alt="baner_tri">
        </div>
    </div>
</div>
<div class="updates_page_content">

        <div class="custom_sub_contaier">

    <?php

    // Start the loop.

    while ( have_posts() ) : the_post();



      // Include the page content template.

      get_template_part( 'content', 'page' );



      // If comments are open or we have at least one comment, load up the comment template.

      if ( comments_open() || get_comments_number() ) :

        comments_template();

      endif;



    // End the loop.

    endwhile;

    ?>

</div></div>


    <div class="main_page_contact">  
        <h5>Stowarzyszenie na Rzecz Rozwoju Regionu<br>Dolina Gubra</h5>
        <p> 
            11-430 Korsze, Studzieniec 27<br>
            <a href="biuro@dolinagubra.pl">biuro@dolinagubra.pl</a><br><br>
            KRS 0000412628 <br>
            REGON 281379846 <br>
            NIP 7422246158<br><br>
            Nr konta:<br><br>
            BGŻ SA O/Kętrzyn 66203000451110000002285110
        </p>
    </div>

<?php get_footer(); ?>

