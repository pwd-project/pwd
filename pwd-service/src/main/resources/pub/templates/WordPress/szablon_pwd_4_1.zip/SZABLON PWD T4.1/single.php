<?php get_header(); ?>

    <div class="custom_sub_contaier">
	<?php
		while ( have_posts() ) : the_post();
			get_template_part( 'content', get_post_format() );
		endwhile;
	?>
	</div>
<?php get_footer(); ?>
