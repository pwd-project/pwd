<?php get_header(); ?>
	<!-- single -->
    <div class="custom_sub_contaier">
	<?php
		while ( have_posts() ) : the_post();
			get_template_part( 'content', get_post_format() );
		endwhile;
	?>
	</div>
	<!-- ./single -->
	    <div class="main_page_contact">  
        <h5>Stowarzyszenie na Rzecz Rozwoju Regionu<br>Dolina Gubra</h5>
        <p> 
            11-430 Korsze, Studzieniec 27<br>
            <a href="biuro@dolinagubra.pl">biuro@dolinagubra.pl</a><br><br>
            KRS 0000412628 <br>
            REGON 281379846 <br>
            NIP 7422246158<br><br>
            Nr konta:<br><br>
            BGŻ SA O/Kętrzyn 66203000451110000002285110
        </p>
    </div>
<?php get_footer(); ?>

