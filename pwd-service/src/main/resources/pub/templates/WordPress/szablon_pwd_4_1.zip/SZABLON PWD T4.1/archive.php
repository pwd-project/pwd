<?php get_header(); ?>
<div class="index_page_content category_banner">    
    <div class="page_baner">    
        <div class="custom_sub_contaier">
        <h5><?php the_archive_title(); ?></h5>
       
       

        </div>
                <div class="arrow_holder">
        <img src="<?php bloginfo('stylesheet_directory'); ?>/img/baner_tri.png" alt="baner_tri">
        </div>
    </div>
</div>
<div class="custom_sub_contaier">
        <div class="posts_row row category_posts"> 
            <?php
                $latest_blog_posts = new WP_Query( array( 'posts_per_page' => 8 ) );
                if ( $latest_blog_posts->have_posts() ) : 
                    while ( $latest_blog_posts->have_posts() ) : $latest_blog_posts->the_post();
                    ?>
                    <div class="col s12 m3 l3 main_post_col">
                        <div class="image_holder">
                        <?php
                            if ( has_post_thumbnail() ) { the_post_thumbnail(); } else { echo '<div style="width:100%; height:200px; border:1px solid black;"></div>'; }
                        ?> 
                        </div>
                        <h5><?php the_title(); ?></h5> 
                        <p><?php $content = get_the_content(); echo mb_strimwidth($content, 0, 150, '...');?></p>
                        <a href="<?php the_title( get_permalink()); ?>">Więcej</a>
                    </div>
                    <?php
                    endwhile; 
                endif;
            ?>
        </div> 
</div>
<?php get_footer(); ?>
