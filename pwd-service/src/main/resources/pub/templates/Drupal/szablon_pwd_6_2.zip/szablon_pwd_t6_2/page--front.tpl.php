<?php if (theme_get_setting('scrolltop_display')): ?>
<div id="toTop"><span class="glyphicon glyphicon-chevron-up"></span></div>
<?php endif; ?>
<script>
(function($) {



$(document).ready(function() {

		$('[data-toggle="tooltip"]').tooltip(); 
		$(window).on("keydown", this, function (event) {
			if (event.keyCode == 116) {
				Cookies.remove('style');
			}
		});
		var plus = 0;
		$('.font-basic').click(function() {
			$('p, span, h1, h2, h3, h4, h5:not(".rank-value"), h6, ul, li, td, th').removeAttr('style');
			plus=0;
		});
		$('.font-plus').click(function() {
			$('p, span, h1, h2, h3, h4, h5:not(".rank-value"), h6, ul, li, td, th').removeAttr('style');
			$('p, .section span, h1, h2, h3, h4, h5:not(".rank-value"), h6, ul, li, td, th').css("font-size", function() {
				plus=plus+1;
				return parseInt($(this).css('font-size')) + 3 + 'px';		
			});
		});
		$('.font-plus-plus').click(function() {
			$('p,  span, h1, h2, h3, h4, h5:not(".rank-value"), h6, ul, li, td, th').removeAttr('style');
			$('p, .section span, h1, h2, h3, h4, h5:not(".rank-value"), h6, ul, li, td, th').css("font-size", function() {
				
				return parseInt($(this).css('font-size')) + 6 + 'px';		
			});
		
		});
		$('.contrast-1').click(function() {
			$('.rank-ico').attr('src','/img/rank.png');
			$('.visible-regular').show();
			$('.visible-contrast').hide();
			$('#contrast-style').remove();
			Cookies.set('style', '1');
		});
		$('.contrast-2').click(function() {
			$('.rank-ico').attr('src','/img/rank-white.png');
			$('.visible-contrast').show();
			$('.visible-regular').hide();
			$('#contrast-style').remove();
			$('head').append('<link id="contrast-style" rel="stylesheet" href="<?php print base_path() . drupal_get_path('theme', 'szablon_pwd_t6_2') ?>/css/contrast-2.css" type="text/css" />');
			Cookies.set('style', '2');
		});
		$('.contrast-3').click(function() {
			$('.rank-ico').attr('src','/img/rank.png');
			$('.visible-contrast').show();
			$('.visible-regular').hide();
			$('#contrast-style').remove();
			$('head').append('<link id="contrast-style" rel="stylesheet" href="<?php print base_path() . drupal_get_path('theme', 'szablon_pwd_t6_2') ?>/css/contrast-3.css" type="text/css" />');
			Cookies.set('style', '3');
		});
		$('.contrast-4').click(function() {
			$('.rank-ico').attr('src','/img/rank-yellow.png');
			$('.visible-contrast').show();
			$('.visible-regular').hide();
			$('#contrast-style').remove();
			$('head').append('<link id="contrast-style" rel="stylesheet" href="<?php print base_path() . drupal_get_path('theme', 'szablon_pwd_t6_2') ?>/css/contrast-4.css" type="text/css" />');
			Cookies.set('style', '4');
		});
		
		var style = Cookies.get('style');
		if(style == 1){
			$('#contrast-style').remove();
			$('.rank-ico').attr('src','/img/rank.png');
		}
		else if(style == 2){
			$('.rank-ico').attr('src','/img/rank-white.png');
			$('head').append('<link id="contrast-style" rel="stylesheet" href="<?php print base_path() . drupal_get_path('theme', 'szablon_pwd_t6_2') ?>/css/contrast-2.css" type="text/css" />');
		}
		else if(style == 3){
			$('.rank-ico').attr('src','/img/rank.png');
			$('head').append('<link id="contrast-style" rel="stylesheet" href="<?php print base_path() . drupal_get_path('theme', 'szablon_pwd_t6_2') ?>/css/contrast-3.css" type="text/css" />');
		}
		else if(style == 4){
			$('.rank-ico').attr('src','/img/rank-yellow.png');
			$('head').append('<link id="contrast-style" rel="stylesheet" href="<?php print base_path() . drupal_get_path('theme', 'szablon_pwd_t6_2') ?>/css/contrast-4.css" type="text/css" />');
		}
		
		
	});

		
})(jQuery);
</script>
 <div data-spy="affix" data-offset-top="60" data-offset-bottom="200" style="display:table; width:100%; background-color:white!important;z-index:1;">
 <div class="container" style="background-color:white!important;">
 <div class="pull-left" style="background-color:white!important;">
 <?php print $pwdlogo; ?>
 </div>
<div class="icons" style="background-color:white!important;">
	<span class="font font-basic" style="color:black!important; background-color:white!important;" title="Podstawowy rozmiar tekstu">
	A
	</span>
	<span class="font font-plus" style="color:black!important; background-color:white!important;" title="Powiększ tekst o 50%">
	A<em>+</em>
	</span>
	<span class="font font-plus-plus" style="color:black!important; background-color:white!important;" title="Powiększ tekst o 100%">
	A<em>++</em>
	</span>
	
	<span class="contrast contrast-1" style="color:black!important; background-color:white!important;" title="Podstawowy kontrast">
	K
	</span>
	<span class="contrast contrast-2" style="color:white!important; background-color:#000!important;" title="Biały tekst na czarnym tle">
	K
	</span>
	<span class="contrast contrast-3" style="color:black!important; background-color:#ffff00!important;" title="Czarny tekst na źółtym tle">
	K
	</span>
	<span class="contrast contrast-4" style="color:#ffff00!important; background-color:#000!important;" title="Żółty tekst na czarnym tle">
	K
	</span>
</div>
<div class="clear"></div> 
</div> 
</div>
<!-- #main-navigation --> 
<div id="main-navigation" class="clearfix">
    <div class="container">

        <!-- #main-navigation-inside -->
        <div id="main-navigation-inside" class="clearfix">
            <div class="row">
                <div class="col-md-12">
						
                    <nav role="navigation" class="navbar">
						
							<!-- Brand and toggle get grouped for better mobile display -->
							<div class="navbar-header">
								<a class="navbar-brand" href="<?php print base_path();?>">
									<?php print $logo; ?>
								</a>						
							<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
								<span class="sr-only">Pokaż/Ukryj nawigacje</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
							
						</div>
						<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
							 <?php print theme('links__system_main_menu', array('links' => $main_menu, 'attributes' => array('class' => array('main-menu', 'menu'), ), 'heading' => array('text' => t('Main menu'), 'level' => 'h2', 'class' => array('element-invisible'), ), )); ?>
						</div>
                       
                    </nav>
					
                </div>
            </div>
        </div>
        <!-- EOF: #main-navigation-inside -->

    </div>
</div>
<!-- EOF: #main-navigation -->

<div class="container-fluid banner-wrapper">
  <div class="row">
<div class="banner-color hidden-xs"><?php print $banner; ?></div></div>
</div>
<div class="container banner-block" ><div class="col-md-8">
    <h1><?php print $banner_title; ?></h1>
    <p><?php print $banner_text; ?></p>
  <a href="<?php print $banner_link1; ?>" class="btn btn-default btn-lg banner-link-1"><?php print $banner_link1_title; ?></a><a href="<?php print $banner_link2; ?>" class="btn btn-default btn-lg banner-link-2"><?php print $banner_link2_title; ?></a>  
</div>
</div>



<!-- #page -->
<div id="page" class="clearfix">
    
    <?php if ($page['highlighted']):?>
    <!-- #top-content -->
    <div id="top-content" class="clearfix">
        <div class="container">

            <!-- #top-content-inside -->
            <div id="top-content-inside" class="clearfix">
                <div class="row">
                    <div class="col-md-12">
                    <?php print render($page['highlighted']); ?>
                    </div>
                </div>
            </div>
            <!-- EOF:#top-content-inside -->

        </div>
    </div>
    <!-- EOF: #top-content -->
    <?php endif; ?>

    <!-- #main-content -->
    <div id="main-content" class="front-page">
        <div class="container">
        
            <!-- #messages-console -->
            <?php if ($messages):?>
            <div id="messages-console" class="clearfix">
                <div class="row">
                    <div class="col-md-12">
                    <?php print $messages; ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <!-- EOF: #messages-console -->
            
            <div class="row">

                


                <section class="col-md-12">

                    <!-- #main -->
                    <div id="main" class="clearfix">
     
                        <?php if ($page['promoted']):?>
                        <!-- #promoted -->
                            <div id="promoted" class="clearfix">
                                <div id="promoted-inside" class="clearfix">
                                <?php print render($page['promoted']); ?>
                                </div>
                            </div>
                        <!-- EOF: #promoted -->
                        <?php endif; ?>

                        <!-- EOF:#content-wrapper -->
                        <div id="content-wrapper">

                            <?php print render($title_prefix); ?>
                            <?php if ($title):?>
                            <h1 class="page-title"><?php print $title; ?></h1>
                            <?php endif; ?>
                            <?php print render($title_suffix); ?>

                            <?php print render($page['help']); ?>
                      
                            <!-- #tabs -->
                            <?php if ($tabs):?>
                                <div class="tabs">
                                <?php print render($tabs); ?>
                                </div>
                            <?php endif; ?>
                            <!-- EOF: #tabs -->

                            <!-- #action links -->
                            <?php if ($action_links):?>
                                <ul class="action-links">
                                <?php print render($action_links); ?>
                                </ul>
                            <?php endif; ?>
                            <!-- EOF: #action links -->

                            <?php print render($page['content']); ?>
                            

                        </div>
						
						
						
                        <!-- EOF:#content-wrapper -->

                    </div>
                    <!-- EOF:#main -->

                </section>

               
        
            </div>

        </div>
		
		
		<div class="container-fluid articles" style=" background-image:url('<?php print base_path() . drupal_get_path('theme', 'szablon_pwd_t6_2')?>/images/local/article-bg.jpg')">
			<div class="container">
			<div class="col-md-4">
				<div class="col-md-12 article">
				<div class="text-overlay">
					<h3><?php print $link1_title; ?></h3>
					<p><?php print $link1_desc; ?></p>
				</div>
				<div class="row article-image">
					<img class="img-responsive" src="<?php print $link1_img; ?>">
				</div>
				</div>
			</div>
			
			<div class="col-md-4">
				<div class="col-md-12 article">
				<div class="text-overlay">
					<h3><?php print $link2_title; ?></h3>
					<p><?php print $link2_desc; ?></p>
				</div>
				<div class="row article-image">
					<img class="img-responsive" src="<?php print $link2_img; ?>">
				</div>
				</div>
			</div>
			
			<div class="col-md-4">
				<div class="col-md-12 article">
				<div class="text-overlay">
					<h3><?php print $link3_title; ?></h3>
					<p><?php print $link3_desc; ?></p>
				</div>
				<div class="row article-image">
					<img class="img-responsive" src="<?php print $link3_img; ?>">
				</div>
				</div>
			</div>
			</div>
		</div>
    </div>
	
    <!-- EOF:#main-content -->

    

</div>
<!-- EOF:#page -->

<footer class="clearfix">
    <div class="container">
        
        <div class="col-md-12 footer-text">
			<h1 class="pull-left"><?php print $footer_title; ?></h1>
			<p class="pull-left"><?php print $footer_text; ?></p>
		</div>
    
    </div>
</footer>
<footer>
    <div class="container">
		<div class="row">
			<div class="col-md-7">
				<p>Strona została opracowana w ramach projektu PWD online realizowanego przez Stowarzyszenie Na Rzecz Rozwoju Regionu Dolina Gubra przy wsparciu Ministerstwa Administracji i Cyfryzacji</a>
				</p>
			</div>
			<div class="col-md-5">	
				<img src="<?php print $foot2; ?>" alt="Ministerstwo Administracji i Cyfryzacji" class="img-responsive pull-right maic"">
				<img src="<?php print $foot1; ?>" class="img-responsive pull-right" alt="Dolina Gubra">
			</div>
		</div>
    </div>
</footer>
<!-- EOF:#subfooter -->