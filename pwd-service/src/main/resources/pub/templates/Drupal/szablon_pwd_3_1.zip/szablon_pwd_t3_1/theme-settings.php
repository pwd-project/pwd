<?php
/**
 * @file
 * Theme setting callbacks for the szablon_pwd_t3_1 theme.
 */

/**
 * Implements hook_form_FORM_ID_alter().
 */
function szablon_pwd_t3_1_form_system_theme_settings_alter(&$form, &$form_state) {
  $form['szablon_pwd_t3_1_settings'] = array(
    '#type' => 'fieldset',
    '#title' => t('szablon_pwd_t3_1 Theme Settings'),
    '#collapsible' => FALSE,
    '#collapsed' => FALSE,
  );
  
  $form['szablon_pwd_t3_1_settings']['sitelogo'] = array(
    '#markup' => t('Żeby zmienić logo zamień plik logo.png w katalogu "images" w katalogu motywu.'),
  );
  
  $form['szablon_pwd_t3_1_settings']['slideshow'] = array(
    '#type' => 'fieldset',
    '#title' => t('Slider'),
    '#collapsible' => TRUE,
    '#collapsed' => FALSE,
  );
  $form['szablon_pwd_t3_1_settings']['slideshow']['slideshow_display'] = array(
    '#type' => 'checkbox',
    '#title' => t('Wyświetlaj slider'),
    '#default_value' => theme_get_setting('slideshow_display', 'szablon_pwd_t3_1'),
  );
  $form['szablon_pwd_t3_1_settings']['slideshow']['slide'] = array(
    '#markup' => t('Możesz zmienić opis slajdu w poniższych ustawieniach.'),
  );
  $form['szablon_pwd_t3_1_settings']['slideshow']['slide1'] = array(
    '#type' => 'fieldset',
    '#title' => t('Slide 1'),
    '#collapsible' => TRUE,
    '#collapsed' => TRUE,
  );
  $form['szablon_pwd_t3_1_settings']['slideshow']['slide1']['slide1_title'] = array(
    '#type' => 'textfield',
    '#title' => t('Tytuł'),
    '#default_value' => theme_get_setting('slide1_title', 'szablon_pwd_t3_1'),
  );
  $form['szablon_pwd_t3_1_settings']['slideshow']['slide1']['slide1_desc'] = array(
    '#type' => 'textfield',
    '#title' => t('Opis'),
    '#default_value' => theme_get_setting('slide1_desc', 'szablon_pwd_t3_1'),
  );
  $form['szablon_pwd_t3_1_settings']['slideshow']['slide2'] = array(
    '#type' => 'fieldset',
    '#title' => t('Slide 2'),
    '#collapsible' => TRUE,
    '#collapsed' => TRUE,
  );
  $form['szablon_pwd_t3_1_settings']['slideshow']['slide2']['slide2_title'] = array(
    '#type' => 'textfield',
    '#title' => t('Tytuł'),
    '#default_value' => theme_get_setting('slide2_title', 'szablon_pwd_t3_1'),
  );
  $form['szablon_pwd_t3_1_settings']['slideshow']['slide2']['slide2_desc'] = array(
    '#type' => 'textfield',
    '#title' => t('Opis'),
    '#default_value' => theme_get_setting('slide2_desc', 'szablon_pwd_t3_1'),
  );
  $form['szablon_pwd_t3_1_settings']['slideshow']['slide3'] = array(
    '#type' => 'fieldset',
    '#title' => t('Slide 3'),
    '#collapsible' => TRUE,
    '#collapsed' => TRUE,
  );
  $form['szablon_pwd_t3_1_settings']['slideshow']['slide3']['slide3_title'] = array(
    '#type' => 'textfield',
    '#title' => t('Tytuł'),
    '#default_value' => theme_get_setting('slide3_title', 'szablon_pwd_t3_1'),
  );
  $form['szablon_pwd_t3_1_settings']['slideshow']['slide3']['slide3_desc'] = array(
    '#type' => 'textfield',
    '#title' => t('Opis'),
    '#default_value' => theme_get_setting('slide3_desc', 'szablon_pwd_t3_1'),
  );
  $form['szablon_pwd_t3_1_settings']['slideshow']['slideimage'] = array(
    '#markup' => t('Żeby zmienić obrazki slajdów, podmień pliki slide-image-1.jpg, slide-image-2.jpg and slide-image-3.jpg w folderze images w katalogu motywu.'),
  );
  
  $form['szablon_pwd_t3_1_settings']['front_links'] = array(
    '#type' => 'fieldset',
    '#title' => t('Zarządzanie linkami w bocznej kolumnie i pod sliderem'),
    '#collapsible' => TRUE,
    '#collapsed' => FALSE,
  );
 
  $form['szablon_pwd_t3_1_settings']['front_links']['column_links'] = array(
    '#markup' => t('Kolumna boczna'),
  );
   $form['szablon_pwd_t3_1_settings']['front_links']['column_dis'] = array(
    '#type' => 'checkbox',
    '#title' => t('Pokazuj linki w kolumnie bocznej'),
    '#default_value' => theme_get_setting('column_dis', 'szablon_pwd_t3_1'),
  );
  $form['szablon_pwd_t3_1_settings']['front_links']['link1'] = array(
    '#type' => 'fieldset',
    '#title' => t('Link 1'),
    '#collapsible' => TRUE,
    '#collapsed' => TRUE,
  );
  $form['szablon_pwd_t3_1_settings']['front_links']['link1']['link1_href'] = array(
    '#type' => 'textfield',
    '#title' => t('Adres linku'),
    '#default_value' => theme_get_setting('link1_href', 'szablon_pwd_t3_1'),
  );
  $form['szablon_pwd_t3_1_settings']['front_links']['link2'] = array(
    '#type' => 'fieldset',
    '#title' => t('Link 2'),
    '#collapsible' => TRUE,
    '#collapsed' => TRUE,
  );
  $form['szablon_pwd_t3_1_settings']['front_links']['link2']['link2_href'] = array(
    '#type' => 'textfield',
    '#title' => t('Adres linku'),
    '#default_value' => theme_get_setting('link2_href', 'szablon_pwd_t3_1'),
  );
  $form['szablon_pwd_t3_1_settings']['front_links']['link3'] = array(
    '#type' => 'fieldset',
    '#title' => t('Link 3'),
    '#collapsible' => TRUE,
    '#collapsed' => TRUE,
  );
  $form['szablon_pwd_t3_1_settings']['front_links']['link3']['link3_href'] = array(
    '#type' => 'textfield',
    '#title' => t('Adres linku'),
    '#default_value' => theme_get_setting('link3_href', 'szablon_pwd_t3_1'),
  );
  $form['szablon_pwd_t3_1_settings']['front_links']['columnimage'] = array(
    '#markup' => t('Żeby zmienić loga, podmień obrazki link1.png, link2.png, link3.png w folderze szablon_pwd_t3_1/images/links.<br><br>'),
  );
  
  $form['szablon_pwd_t3_1_settings']['front_links']['slider_links'] = array(
    '#markup' => t('Obszar pod sliderem'),
  );
  
   $form['szablon_pwd_t3_1_settings']['front_links']['slider_dis'] = array(
    '#type' => 'checkbox',
    '#title' => t('Pokazuj linki w obszarze pod sliderem.'),
    '#default_value' => theme_get_setting('slider_dis', 'szablon_pwd_t3_1'),
  );
  
  $form['szablon_pwd_t3_1_settings']['front_links']['link4'] = array(
    '#type' => 'fieldset',
    '#title' => t('Link 1'),
    '#collapsible' => TRUE,
    '#collapsed' => TRUE,
  );
  $form['szablon_pwd_t3_1_settings']['front_links']['link4']['link4_href'] = array(
    '#type' => 'textfield',
    '#title' => t('Adres linku'),
    '#default_value' => theme_get_setting('link4_href', 'szablon_pwd_t3_1'),
  );
  $form['szablon_pwd_t3_1_settings']['front_links']['link4']['link4_title'] = array(
    '#type' => 'textfield',
    '#title' => t('Tytuł linku'),
    '#default_value' => theme_get_setting('link4_title', 'szablon_pwd_t3_1'),
  );
  $form['szablon_pwd_t3_1_settings']['front_links']['link4']['link4_desc'] = array(
    '#type' => 'textfield',
    '#title' => t('Opis linku'),
    '#default_value' => theme_get_setting('link4_desc', 'szablon_pwd_t3_1'),
  );
  $form['szablon_pwd_t3_1_settings']['front_links']['link5'] = array(
    '#type' => 'fieldset',
    '#title' => t('Link 2'),
    '#collapsible' => TRUE,
    '#collapsed' => TRUE,
  );
  $form['szablon_pwd_t3_1_settings']['front_links']['link5']['link5_href'] = array(
    '#type' => 'textfield',
    '#title' => t('Adres linku'),
    '#default_value' => theme_get_setting('link5_href', 'szablon_pwd_t3_1'),
  );
   $form['szablon_pwd_t3_1_settings']['front_links']['link5']['link5_title'] = array(
    '#type' => 'textfield',
    '#title' => t('Tytuł linku'),
    '#default_value' => theme_get_setting('link5_title', 'szablon_pwd_t3_1'),
  );
  $form['szablon_pwd_t3_1_settings']['front_links']['link5']['link5_desc'] = array(
    '#type' => 'textfield',
    '#title' => t('Opis linku'),
    '#default_value' => theme_get_setting('link5_desc', 'szablon_pwd_t3_1'),
  );
  $form['szablon_pwd_t3_1_settings']['front_links']['sliderimage'] = array(
    '#markup' => t('Żeby zmienić loga, podmień obrazki link4.png, link5.png w folderze szablon_pwd_t3_1/images/links.'),
  );
  
  $form['szablon_pwd_t3_1_settings']['social'] = array(
    '#type' => 'fieldset',
    '#title' => t('Social Icon'),
    '#collapsible' => TRUE,
    '#collapsed' => FALSE,
  );
  $form['szablon_pwd_t3_1_settings']['social']['display'] = array(
    '#type' => 'checkbox',
    '#title' => t('Wyświetlaj ikonki social media'),
    '#default_value' => theme_get_setting('display', 'szablon_pwd_t3_1'),
  );
  $form['szablon_pwd_t3_1_settings']['social']['twitter'] = array(
    '#type' => 'textfield',
    '#title' => t('Twitter URL'),
    '#default_value' => theme_get_setting('twitter', 'szablon_pwd_t3_1'),
  );
  $form['szablon_pwd_t3_1_settings']['social']['facebook'] = array(
    '#type' => 'textfield',
    '#title' => t('Facebook URL'),
    '#default_value' => theme_get_setting('facebook', 'szablon_pwd_t3_1'),
  );
  $form['szablon_pwd_t3_1_settings']['social']['linkedin'] = array(
    '#type' => 'textfield',
    '#title' => t('LinkedIn URL'),
    '#default_value' => theme_get_setting('linkedin', 'szablon_pwd_t3_1'),
  );
  
}
