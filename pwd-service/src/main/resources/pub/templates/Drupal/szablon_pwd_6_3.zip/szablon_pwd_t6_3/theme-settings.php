<?php
/**
 * Implements hook_form_FORM_ID_alter().
 *
 * @param $form
 *   The form.
 * @param $form_state
 *   The form state.
 */
function szablon_pwd_t6_3_form_system_theme_settings_alter(&$form, &$form_state) {
    
    $form['mtt_settings'] = array(
        '#type' => 'fieldset',
        '#title' => t('Ustawienia motywu'),
        '#collapsible' => FALSE,
        '#collapsed' => FALSE,
    );
	
	$form['mtt_settings']['contact']['title'] = array(
    '#markup' => t('Sekcja Kontakt'),
  );
  $form['mtt_settings']['contact']['marker_coord'] = array(
    '#type' => 'textfield',
    '#title' => t('Współrzędne znacznika Google Maps'),
    '#default_value' => theme_get_setting('marker_coord', 'szablon_pwd_t6_3'),
  );
  $form['mtt_settings']['contact']['maps_coord'] = array(
    '#type' => 'textfield',
    '#title' => t('Współrzędne środka Google Maps'),
    '#default_value' => theme_get_setting('maps_coord', 'szablon_pwd_t6_3'),
  );
  $form['mtt_settings']['contact']['contact_title'] = array(
    '#type' => 'textfield',
    '#title' => t('Tytuł'),
    '#default_value' => theme_get_setting('contact_title', 'szablon_pwd_t6_3'),
  );
  $form['mtt_settings']['contact']['contact_text'] = array(
    '#type' => 'textarea',
    '#title' => t('Dane kontaktowe'),
    '#default_value' => theme_get_setting('contact_text', 'szablon_pwd_t6_3'),
	'#description' => 'Użyj znacznika "<br>", żeby przenieść tekst do nowej linii',
  );
	
	
	$form['mtt_settings']['banner_link']['banner_links'] = array(
    '#markup' => t('Banner strony'),
  );
  $form['mtt_settings']['banner_link']['banner_title'] = array(
    '#type' => 'textfield',
    '#title' => t('Tytuł'),
    '#default_value' => theme_get_setting('banner_title', 'szablon_pwd_t6_3'),
  );
  $form['mtt_settings']['banner_link']['banner_text'] = array(
    '#type' => 'textarea',
    '#title' => t('Treść'),
    '#default_value' => theme_get_setting('banner_text', 'szablon_pwd_t6_3'),
  );
	
	$form['mtt_settings']['banner_link']['link1'] = array(
    '#type' => 'fieldset',
    '#title' => t('Link 1'),
    '#collapsible' => TRUE,
    '#collapsed' => TRUE,
  );
  $form['mtt_settings']['banner_link']['link1']['banner_link1_title'] = array(
    '#type' => 'textfield',
    '#title' => t('Tytuł'),
    '#default_value' => theme_get_setting('banner_link1_title', 'szablon_pwd_t6_3'),
  );
  $form['mtt_settings']['banner_link']['link1']['banner_link1'] = array(
    '#type' => 'textfield',
    '#title' => t('Adres'),
    '#default_value' => theme_get_setting('banner_link1', 'szablon_pwd_t6_3'),
  );
  $form['mtt_settings']['banner_link']['link2'] = array(
    '#type' => 'fieldset',
    '#title' => t('Link 2'),
    '#collapsible' => TRUE,
    '#collapsed' => TRUE,
  );
   $form['mtt_settings']['banner_link']['link2']['banner_link2_title'] = array(
    '#type' => 'textfield',
    '#title' => t('Tytuł'),
    '#default_value' => theme_get_setting('banner_link2_title', 'szablon_pwd_t6_3'),
  );
  $form['mtt_settings']['banner_link']['link2']['banner_link2'] = array(
    '#type' => 'textfield',
    '#title' => t('Adres'),
    '#default_value' => theme_get_setting('banner_link2', 'szablon_pwd_t6_3'),
  );
	
	
	$form['mtt_settings']['front_links']['slider_links'] = array(
    '#markup' => t('Boksy na dole strony'),
  );
  
   $form['mtt_settings']['front_links']['link_display'] = array(
    '#type' => 'checkbox',
    '#title' => t('Pokazuj boksy w obszarze na dole strony.'),
    '#default_value' => theme_get_setting('link_display', 'szablon_pwd_t6_3'),
  );
  
  $form['mtt_settings']['front_links']['link1'] = array(
    '#type' => 'fieldset',
    '#title' => t('Boks 1'),
    '#collapsible' => TRUE,
    '#collapsed' => TRUE,
  );
  /*$form['mtt_settings']['front_links']['link1']['link1_href'] = array(
    '#type' => 'textfield',
    '#title' => t('Adres linku'),
    '#default_value' => theme_get_setting('link1_href', 'szablon_pwd_t6_3'),
  );*/
  $form['mtt_settings']['front_links']['link1']['link1_title'] = array(
    '#type' => 'textfield',
    '#title' => t('Tytuł'),
    '#default_value' => theme_get_setting('link1_title', 'szablon_pwd_t6_3'),
  );
  $form['mtt_settings']['front_links']['link1']['link1_desc'] = array(
    '#type' => 'textfield',
    '#title' => t('Opis'),
    '#default_value' => theme_get_setting('link1_desc', 'szablon_pwd_t6_3'),
  );
  $form['mtt_settings']['front_links']['link2'] = array(
    '#type' => 'fieldset',
    '#title' => t('Boks 2'),
    '#collapsible' => TRUE,
    '#collapsed' => TRUE,
  );
  /*$form['mtt_settings']['front_links']['link2']['link2_href'] = array(
    '#type' => 'textfield',
    '#title' => t('Adres linku'),
    '#default_value' => theme_get_setting('link2_href', 'szablon_pwd_t6_3'),
  );*/
   $form['mtt_settings']['front_links']['link2']['link2_title'] = array(
    '#type' => 'textfield',
    '#title' => t('Tytuł'),
    '#default_value' => theme_get_setting('link2_title', 'szablon_pwd_t6_3'),
  );
  $form['mtt_settings']['front_links']['link2']['link2_desc'] = array(
    '#type' => 'textfield',
    '#title' => t('Opis'),
    '#default_value' => theme_get_setting('link2_desc', 'szablon_pwd_t6_3'),
  );
  
  $form['mtt_settings']['front_links']['link3'] = array(
    '#type' => 'fieldset',
    '#title' => t('Boks 3'),
    '#collapsible' => TRUE,
    '#collapsed' => TRUE,
  );
  /*$form['mtt_settings']['front_links']['link3']['link3_href'] = array(
    '#type' => 'textfield',
    '#title' => t('Adres linku'),
    '#default_value' => theme_get_setting('link3_href', 'szablon_pwd_t6_3'),
  );*/
   $form['mtt_settings']['front_links']['link3']['link3_title'] = array(
    '#type' => 'textfield',
    '#title' => t('Tytuł'),
    '#default_value' => theme_get_setting('link3_title', 'szablon_pwd_t6_3'),
  );
  $form['mtt_settings']['front_links']['link3']['link3_desc'] = array(
    '#type' => 'textfield',
    '#title' => t('Opis'),
    '#default_value' => theme_get_setting('link3_desc', 'szablon_pwd_t6_3'),
  );
  
  $form['mtt_settings']['front_links']['sliderimage'] = array(
    '#markup' => t('Żeby zmienić loga, podmień obrazki link1.jpg, link2.jpg, link3.jpg w folderze szablon_pwd_t6_3/images/local.'),
  );
  
  $form['mtt_settings']['footer']['footer_d'] = array(
    '#markup' => t('Wyświetlaj stopkę'),
  );
  
   $form['mtt_settings']['footer']['footer_display'] = array(
    '#type' => 'checkbox',
    '#title' => t('Pokazuj stopkę na dole strony.'),
    '#default_value' => theme_get_setting('footer_display', 'szablon_pwd_t6_3'),
  );
  
  $form['mtt_settings']['footer']['footer1'] = array(
    '#type' => 'fieldset',
    '#title' => t('Stopka'),
    '#collapsible' => TRUE,
    '#collapsed' => TRUE,
  );
  $form['mtt_settings']['footer']['footer1']['footer_title'] = array(
    '#type' => 'textfield',
    '#title' => t('Tytuł'),
    '#default_value' => theme_get_setting('footer_title', 'szablon_pwd_t6_3'),
  );
  $form['mtt_settings']['footer']['footer1']['footer_text'] = array(
    '#type' => 'textarea',
    '#title' => t('Treść'),
    '#default_value' => theme_get_setting('footer_text', 'szablon_pwd_t6_3'),
  );

    $form['mtt_settings']['tabs'] = array(
        '#type' => 'vertical_tabs',
    );

    $form['mtt_settings']['tabs']['basic_settings'] = array(
        '#type' => 'fieldset',
        '#title' => t('Basic Settings'),
        '#collapsible' => TRUE,
        '#collapsed' => TRUE,
    );

    $form['mtt_settings']['tabs']['basic_settings']['breadcrumb_display'] = array(
        '#type' => 'checkbox',
        '#title' => t('Show breadcrumb'),
        '#description'   => t('Use the checkbox to enable or disable the breadcrumb.'),
        '#default_value' => theme_get_setting('breadcrumb_display','szablon_pwd_t6_3'),
    );

    $form['mtt_settings']['tabs']['basic_settings']['scrolltop_display'] = array(
        '#type' => 'checkbox',
        '#title' => t('Show scroll-to-top button'),
        '#description'   => t('Use the checkbox to enable or disable scroll-to-top button.'),
        '#default_value' => theme_get_setting('scrolltop_display', 'szablon_pwd_t6_3'),
        '#collapsible' => TRUE,
        '#collapsed' => TRUE,
    );

    $form['mtt_settings']['tabs']['bootstrap_cdn'] = array(
        '#type' => 'fieldset',
        '#title' => t('BootstrapCDN'),
        '#group' => 'bootstrap',
    );
    
    $form['mtt_settings']['tabs']['bootstrap_cdn']['bootstrap_css_cdn'] = array(
        '#type' => 'select',
        '#title' => t('BootstrapCDN Complete CSS version'),
        '#options' => drupal_map_assoc(array(
          '3.2.0',
        )),
        '#default_value' => theme_get_setting('bootstrap_css_cdn'),
        '#empty_value' => NULL,
    );
    
    $form['mtt_settings']['tabs']['bootstrap_cdn']['bootstrap_js_cdn'] = array(
        '#type' => 'select',
        '#title' => t('BootstrapCDN Complete JavaScript version'),
        '#options' => drupal_map_assoc(array(
          '3.2.0',
        )),
        '#default_value' => theme_get_setting('bootstrap_js_cdn'),
        '#empty_option' => t('Disabled'),
        '#empty_value' => NULL,
    );

    $form['mtt_settings']['tabs']['ie8_support'] = array(
        '#type' => 'fieldset',
        '#title' => t('IE8 support'),
        '#collapsible' => TRUE,
        '#collapsed' => FALSE,
    );

    $form['mtt_settings']['tabs']['ie8_support']['responsive_respond'] = array(
        '#type' => 'checkbox',
        '#title' => t('Add Respond.js [<em>bootstrap-business/js/respond.min.js</em>] JavaScript to add basic CSS3 media query support to IE 6-8.'),
        '#default_value' => theme_get_setting('responsive_respond','szablon_pwd_t6_3'),
        '#description'   => t('IE 6-8 require a JavaScript polyfill solution to add basic support of CSS3 media queries. Note that you should enable <strong>Aggregate and compress CSS files</strong> through <em>/admin/config/development/performance</em>.'),
    );
    
}