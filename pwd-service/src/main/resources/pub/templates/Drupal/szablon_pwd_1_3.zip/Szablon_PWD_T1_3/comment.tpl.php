<?php
	$vars = get_defined_vars();
	$view = Szablon_PWD_T1_3_art_get_drupal_view();
	$view->print_comment($vars);
?>