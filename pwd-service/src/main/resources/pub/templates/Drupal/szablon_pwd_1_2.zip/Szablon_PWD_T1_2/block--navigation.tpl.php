<?php echo Szablon_PWD_T1_2_art_hmenu_output($content);?>
