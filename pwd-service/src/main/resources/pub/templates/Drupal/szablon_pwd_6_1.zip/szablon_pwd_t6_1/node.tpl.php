<article id="node-<?php print $node->nid; ?>" class="<?php if (drupal_is_front_page()) {print "col-md-3 col-sm-12 front-page-item ";} print $classes; ?> clearfix"<?php print $attributes; ?>>
  

  <div class="content"<?php print $content_attributes; ?>>
  <?php if ($title_prefix || $title_suffix || $display_submitted): ?>
	<?php print render($title_prefix); ?>
    <div class="pull-left"> <?php  print render($content['field_image']); ?></div>
	<div class="art">
      <h4<?php print $title_attributes; ?>><a href="<?php print $node_url; ?>"><?php print $title; ?></a></h4>
    
    <?php print render($title_suffix); ?>
	

    <?php if ($display_submitted): ?>
      <div class="submitted">
        <?php print $user_picture; ?>
        <?php print $submitted; ?>
      </div>
    <?php endif; ?>
	<?php endif; ?>
	
    <?php
      // We hide the comments and links now so that we can render them later.
	  
      hide($content['comments']);
      hide($content['links']);
      hide($content['field_tags']);
	  hide($content['field_image']);

      print render($content);
    ?>
	</div>
  </div>
    
    <?php if (($tags = render($content['field_tags'])) || ($links = render($content['links']))): ?>
    <footer>
    <?php print render($content['field_tags']); ?>
    <?php print render($content['links']); ?>
    </footer>
    <?php endif; ?> 

  <?php print render($content['comments']); ?>

</article>