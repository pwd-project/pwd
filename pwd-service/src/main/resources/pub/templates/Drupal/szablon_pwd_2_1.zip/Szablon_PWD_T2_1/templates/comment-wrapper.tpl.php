<?php
	$vars = get_defined_vars();
	$view = Szablon_PWD_T2_1_art_get_drupal_view();
	$view->print_comment_wrapper($vars);
?>