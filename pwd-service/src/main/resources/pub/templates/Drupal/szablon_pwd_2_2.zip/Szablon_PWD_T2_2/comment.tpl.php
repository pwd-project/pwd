<?php
	$vars = get_defined_vars();
	$view = Szablon_PWD_T2_2_art_get_drupal_view();
	$view->print_comment($vars);
?>