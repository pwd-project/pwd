<?php $theme_path = base_path() . path_to_theme(); ?>
<div id="ttr_page"class="container">
<div class="ttr_banner_header">
<?php
if( !empty($page['headerabovecolumn1'])|| !empty($page['headerabovecolumn2'])|| !empty($page['headerabovecolumn3'])||!empty($page['headerabovecolumn4'])):
?>
<div class="ttr_banner_header_inner_above0">
<?php
$showcolumn= !empty($page['headerabovecolumn1']);
?>
<?php if($showcolumn): ?>
<div class="cell1 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="headerabovecolumn1">
<?php print render($page['headerabovecolumn1']); ?>
</div>
</div>
<?php else: ?>
<div class="cell1 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-xs-block">
</div>
<?php
$showcolumn= !empty($page['headerabovecolumn2']);
?>
<?php if($showcolumn): ?>
<div class="cell2 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="headerabovecolumn2">
<?php print render($page['headerabovecolumn2']); ?>
</div>
</div>
<?php else: ?>
<div class="cell2 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-sm-block visible-md-block visible-xs-block">
</div>
<?php
$showcolumn= !empty($page['headerabovecolumn3']);
?>
<?php if($showcolumn): ?>
<div class="cell3 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="headerabovecolumn3">
<?php print render($page['headerabovecolumn3']); ?>
</div>
</div>
<?php else: ?>
<div class="cell3 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-xs-block">
</div>
<?php
$showcolumn= !empty($page['headerabovecolumn4']);
?>
<?php if($showcolumn): ?>
<div class="cell4 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="headerabovecolumn4">
<?php print render($page['headerabovecolumn4']); ?>
</div>
</div>
<?php else: ?>
<div class="cell4 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-lg-block visible-sm-block visible-md-block visible-xs-block">
</div>
</div>
<?php endif; ?>
</div>
<div style="height:0px;width:0px;overflow:hidden;-webkit-margin-top-collapse: separate;"></div>
<header id="ttr_header">
<div id="ttr_header_inner">
<div style="height:0px;width:0px;overflow:hidden;-webkit-margin-top-collapse: separate;"></div>
<div class="innermenu"><nav id="ttr_menu" class="navbar-default navbar"> 
<div id="ttr_menu_inner_in"> 
<div class="menuforeground">
</div>
<div id="navigationmenu">
<div class="navbar-header">
<button id="nav-expander" data-target=".navbar-collapse" data-toggle="collapse" class="navbar-toggle" type="button">
<span class="sr-only">
</span>
<span class="icon-bar">
</span>
<span class="icon-bar">
</span>
<span class="icon-bar">
</span>
</button>
</div>
<div class="menu-center collapse navbar-collapse">
<ul class="ttr_menu_items nav navbar-nav navbar-right">
<?php if ($main_menu){ echo generate_menu("ttr_");}?>
<?php $theme_path = base_path() . path_to_theme(); ?>
</ul>
</div>
</div>
</div>
</nav>

</div>
<a href="http://www.templatetoaster.com" class="headerforeground01">
</a>
</div>
</header>
<div class="ttr_banner_header">
<?php
if( !empty($page['headerbelowcolumn1'])|| !empty($page['headerbelowcolumn2'])|| !empty($page['headerbelowcolumn3'])||!empty($page['headerbelowcolumn4'])):
?>
<div class="ttr_banner_header_inner_below0">
<?php
$showcolumn= !empty($page['headerbelowcolumn1']);
?>
<?php if($showcolumn): ?>
<div class="cell1 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="headerbelowcolumn1">
<?php print render($page['headerbelowcolumn1']); ?>
</div>
</div>
<?php else: ?>
<div class="cell1 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-xs-block">
</div>
<?php
$showcolumn= !empty($page['headerbelowcolumn2']);
?>
<?php if($showcolumn): ?>
<div class="cell2 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="headerbelowcolumn2">
<?php print render($page['headerbelowcolumn2']); ?>
</div>
</div>
<?php else: ?>
<div class="cell2 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-sm-block visible-md-block visible-xs-block">
</div>
<?php
$showcolumn= !empty($page['headerbelowcolumn3']);
?>
<?php if($showcolumn): ?>
<div class="cell3 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="headerbelowcolumn3">
<?php print render($page['headerbelowcolumn3']); ?>
</div>
</div>
<?php else: ?>
<div class="cell3 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-xs-block">
</div>
<?php
$showcolumn= !empty($page['headerbelowcolumn4']);
?>
<?php if($showcolumn): ?>
<div class="cell4 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="headerbelowcolumn4">
<?php print render($page['headerbelowcolumn4']); ?>
</div>
</div>
<?php else: ?>
<div class="cell4 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-lg-block visible-sm-block visible-md-block visible-xs-block">
</div>
</div>
<?php endif; ?>
</div>
<div id="ttr_content_and_sidebar_container">
<?php
$showleft= !empty($page['sidebar_first']);
?>
<?php if($showleft): ?>
<aside id="ttr_sidebar_left">
<div id="ttr_sidebar_left_margin">
<div style="height:0px;width:0px;overflow:hidden;-webkit-margin-top-collapse: separate;"></div>
<?php print render($page['sidebar_first']); ?>
<div style="height:0px;width:0px;overflow:hidden;-webkit-margin-top-collapse: separate;"></div>
</div>
</aside> 
<?php endif; ?>
<?php if($showleft){
?>
<div id="ttr_content">
<?php
}
else{
?>
<div id="ttr_content" class="zero_column" style="width:1440px">
<?php
}
?>
<div id="ttr_content_margin" class="container-fluid">
<div style="height:0px;width:0px;overflow:hidden;-webkit-margin-top-collapse: separate;"></div>
<?php if ($breadcrumb): ?>
<?php print $breadcrumb; ?>
<?php endif; ?>
<?php
if( !empty($page['contenttopcolumn1'])|| !empty($page['contenttopcolumn2'])|| !empty($page['contenttopcolumn3'])||!empty($page['contenttopcolumn4'])):
?>
<div class="contenttopcolumn0">
<?php
$showcolumn= !empty($page['contenttopcolumn1']);
?>
<?php if($showcolumn): ?>
<div class="cell1 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="topcolumn1">
<?php print render($page['contenttopcolumn1']); ?>
</div>
</div>
<?php else: ?>
<div class="cell1 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-xs-block">
</div>
<?php
$showcolumn= !empty($page['contenttopcolumn2']);
?>
<?php if($showcolumn): ?>
<div class="cell2 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="topcolumn2">
<?php print render($page['contenttopcolumn2']); ?>
</div>
</div>
<?php else: ?>
<div class="cell2 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-sm-block visible-md-block visible-xs-block">
</div>
<?php
$showcolumn= !empty($page['contenttopcolumn3']);
?>
<?php if($showcolumn): ?>
<div class="cell3 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="topcolumn3">
<?php print render($page['contenttopcolumn3']); ?>
</div>
</div>
<?php else: ?>
<div class="cell3 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-xs-block">
</div>
<?php
$showcolumn= !empty($page['contenttopcolumn4']);
?>
<?php if($showcolumn): ?>
<div class="cell4 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="topcolumn4">
<?php print render($page['contenttopcolumn4']); ?>
</div>
</div>
<?php else: ?>
<div class="cell4 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-lg-block visible-sm-block visible-md-block visible-xs-block">
</div>
</div>
<?php endif; ?>
<div style="height:0px;width:0px;overflow:hidden;-webkit-margin-top-collapse: separate;"></div>
<div style="clear:both;">
</div>
 <?php if ($tabs): ?>
<div style="clear:both;" class="tabs"><?php print render($tabs); ?></div>
 <?php endif; ?>
<?php print render($page['help']); ?>
 <?php print $messages; ?>
<?php if ($action_links): ?>
<ul class="action-links"><?php print render($action_links); ?></ul><?php endif; ?>
<div class="row">
<?php print render($page['content']); ?>
</div>
<?php
if( !empty($page['contentbottomcolumn1'])|| !empty($page['contentbottomcolumn2'])|| !empty($page['contentbottomcolumn3'])||!empty($page['contentbottomcolumn4'])):
?>
<div class="contentbottomcolumn0">
<?php
$showcolumn= !empty($page['contentbottomcolumn1']);
?>
<?php if($showcolumn): ?>
<div class="cell1 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="bottomcolumn1">
<?php print render($page['contentbottomcolumn1']); ?>
</div>
</div>
<?php else: ?>
<div class="cell1 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-xs-block">
</div>
<?php
$showcolumn= !empty($page['contentbottomcolumn2']);
?>
<?php if($showcolumn): ?>
<div class="cell2 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="bottomcolumn2">
<?php print render($page['contentbottomcolumn2']); ?>
</div>
</div>
<?php else: ?>
<div class="cell2 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-sm-block visible-md-block visible-xs-block">
</div>
<?php
$showcolumn= !empty($page['contentbottomcolumn3']);
?>
<?php if($showcolumn): ?>
<div class="cell3 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="bottomcolumn3">
<?php print render($page['contentbottomcolumn3']); ?>
</div>
</div>
<?php else: ?>
<div class="cell3 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-xs-block">
</div>
<?php
$showcolumn= !empty($page['contentbottomcolumn4']);
?>
<?php if($showcolumn): ?>
<div class="cell4 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="bottomcolumn4">
<?php print render($page['contentbottomcolumn4']); ?>
</div>
</div>
<?php else: ?>
<div class="cell4 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-lg-block visible-sm-block visible-md-block visible-xs-block">
</div>
</div>
<?php endif; ?>
</div> 
</div> 
<div style="clear:both;">
</div>
</div>
<div class="footer-widget-area">
<div class="footer-widget-area_left_border_image">
<div class="footer-widget-area_right_border_image">
<div class="footer-widget-area_inner">
<?php
if( !empty($page['footerabovecolumn1'])|| !empty($page['footerabovecolumn2'])|| !empty($page['footerabovecolumn3'])||!empty($page['footerabovecolumn4'])):
?>
<div class="ttr_footer-widget-area_inner_above0">
<?php
$showcolumn= !empty($page['footerabovecolumn1']);
?>
<?php if($showcolumn): ?>
<div class="cell1 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="footerabovecolumn1">
<?php print render($page['footerabovecolumn1']); ?>
</div>
</div>
<?php else: ?>
<div class="cell1 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-xs-block">
</div>
<?php
$showcolumn= !empty($page['footerabovecolumn2']);
?>
<?php if($showcolumn): ?>
<div class="cell2 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="footerabovecolumn2">
<?php print render($page['footerabovecolumn2']); ?>
</div>
</div>
<?php else: ?>
<div class="cell2 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-sm-block visible-md-block visible-xs-block">
</div>
<?php
$showcolumn= !empty($page['footerabovecolumn3']);
?>
<?php if($showcolumn): ?>
<div class="cell3 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="footerabovecolumn3">
<?php print render($page['footerabovecolumn3']); ?>
</div>
</div>
<?php else: ?>
<div class="cell3 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-xs-block">
</div>
<?php
$showcolumn= !empty($page['footerabovecolumn4']);
?>
<?php if($showcolumn): ?>
<div class="cell4 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="footerabovecolumn4">
<?php print render($page['footerabovecolumn4']); ?>
</div>
</div>
<?php else: ?>
<div class="cell4 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-lg-block visible-sm-block visible-md-block visible-xs-block">
</div>
</div>
<?php endif; ?>
</div>
</div>
</div>
</div>
<div style="height:0px;width:0px;overflow:hidden;-webkit-margin-top-collapse: separate;"></div>
<footer id="ttr_footer">
<div id="ttr_footer_top_for_widgets">
<div  class="ttr_footer_top_for_widgets_inner">
<?php
if (   !empty($page['leftfooterarea']) || !empty($page['centerfooterarea']) || !empty($page['rightfooterarea'])):
?>
<div class="footer-widget-area_fixed">
<div style="margin:0 auto;">
<?php if(!empty($page['leftfooterarea'])): ?>
<div  id="first" class="widget-area">
<?php print render($page['leftfooterarea']); ?>
</div>
<?php else: ?>
<div  id="first" class="widget-area">
&nbsp;
</div>
<?php endif; ?>
<?php if(!empty($page['centerfooterarea'])): ?>
<div  id="second" class="widget-area">
<?php print render($page['centerfooterarea']); ?>
</div>
<?php else: ?>
<div  id="second" class="widget-area">
&nbsp;
</div>
<?php endif; ?>
<?php if(!empty($page['rightfooterarea'])): ?>
<div  id="third" class="widget-area">
<?php print render($page['rightfooterarea']); ?>
</div>
<?php else: ?>
<div  id="third" class="widget-area">
&nbsp;
</div>
<?php endif; ?>
</div>
</div>
<?php endif; ?>
</div>
</div>
<div class="ttr_footer_bottom_footer">
<div class="ttr_footer_bottom_footer_inner">
<div id="ttr_copyright">
<a href="<?php print $front_page; ?>">
Copyright@Example.com
</a>
</div>
<div id="ttr_footer_designed_by_links">
<a href="http://templatetoaster.com"> Drupal Theme </a>
<span id="ttr_footer_designed_by"> Designed With TemplateToaster </span></div>
<?php  print $feed_icons;   ?>
<a href=""class="ttr_footer_facebook">
</a>
<a href=""class="ttr_footer_linkedin">
</a>
<a href=""class="ttr_footer_twitter">
</a>
<a href=""class="ttr_footer_googleplus">
</a>
</div>
</div>
</footer>
<div style="height:0px;width:0px;overflow:hidden;-webkit-margin-top-collapse: separate;"></div>
<div class="footer-widget-area">
<?php
if( !empty($page['footerbelowcolumn1'])|| !empty($page['footerbelowcolumn2'])|| !empty($page['footerbelowcolumn3'])||!empty($page['footerbelowcolumn4'])):
?>
<div class="ttr_footer-widget-area_inner_below0">
<?php
$showcolumn= !empty($page['footerbelowcolumn1']);
?>
<?php if($showcolumn): ?>
<div class="cell1 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="footerbelowcolumn1">
<?php print render($page['footerbelowcolumn1']); ?>
</div>
</div>
<?php else: ?>
<div class="cell1 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-xs-block">
</div>
<?php
$showcolumn= !empty($page['footerbelowcolumn2']);
?>
<?php if($showcolumn): ?>
<div class="cell2 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="footerbelowcolumn2">
<?php print render($page['footerbelowcolumn2']); ?>
</div>
</div>
<?php else: ?>
<div class="cell2 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-sm-block visible-md-block visible-xs-block">
</div>
<?php
$showcolumn= !empty($page['footerbelowcolumn3']);
?>
<?php if($showcolumn): ?>
<div class="cell3 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="footerbelowcolumn3">
<?php print render($page['footerbelowcolumn3']); ?>
</div>
</div>
<?php else: ?>
<div class="cell3 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-xs-block">
</div>
<?php
$showcolumn= !empty($page['footerbelowcolumn4']);
?>
<?php if($showcolumn): ?>
<div class="cell4 col-lg-3 col-md-6 col-sm-6  col-xs-12">
<div class="footerbelowcolumn4">
<?php print render($page['footerbelowcolumn4']); ?>
</div>
</div>
<?php else: ?>
<div class="cell4 col-lg-3 col-md-6 col-sm-6  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-lg-block visible-sm-block visible-md-block visible-xs-block">
</div>
</div>
<?php endif; ?>
</div>
</div>
